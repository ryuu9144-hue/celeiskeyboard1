package com.celeis.keyboard.layout

import com.celeis.keyboard.prefs.OneHandedMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LayoutCalculatorTest {

    @Test
    fun computeKeyRects_scalesAndPositionsForOneHandedModes() {
        val rows = KeyboardLayouts.getRows(
            page = KeyboardPage.QWERTY,
            showNumberRow = true,
            showNumberRowInSymbols = true,
            showEmojiKey = true,
            showVoiceKey = true,
            showAltChars = true
        )
        val fullWidth = 1080f
        val height = 780f

        val normalRects = LayoutCalculator.computeKeyRects(
            rows = rows,
            availableWidthPx = fullWidth,
            keyboardHeightPx = height,
            widthPercent = 100,
            oneHandedMode = OneHandedMode.OFF,
            oneHandedWidthPercent = 80,
            hSpacingPx = 8f,
            vSpacingPx = 12f
        )
        assertTrue(normalRects.isNotEmpty())
        assertTrue(normalRects.all { it.width() > 0f && it.height() > 0f })

        val leftWidth = LayoutCalculator.computeKeyboardWidthPx(fullWidth, 100, OneHandedMode.LEFT, 80)
        assertEquals(864f, leftWidth, 0.5f)
        assertEquals(0f, LayoutCalculator.computeHorizontalOffsetPx(fullWidth, leftWidth, OneHandedMode.LEFT), 0.5f)

        val rightOffset = LayoutCalculator.computeHorizontalOffsetPx(fullWidth, leftWidth, OneHandedMode.RIGHT)
        assertEquals(216f, rightOffset, 0.5f)
    }
}
