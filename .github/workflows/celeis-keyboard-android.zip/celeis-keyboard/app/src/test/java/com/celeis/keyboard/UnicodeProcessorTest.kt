package com.celeis.keyboard.unicode

import org.junit.Assert.assertEquals
import org.junit.Test

class UnicodeProcessorTest {

    @Test
    fun normalMode_doesNotAppendWordJoiner() {
        assertEquals("a", UnicodeProcessor.processInput("a", TypingMode.NORMAL))
        assertEquals("Z", UnicodeProcessor.processInput("Z", TypingMode.NORMAL))
        assertEquals("hello", UnicodeProcessor.processInput("hello", TypingMode.NORMAL))
    }

    @Test
    fun unicodeMode_appendsWordJoinerToEnglishLettersOnly() {
        assertEquals("a\u2060", UnicodeProcessor.processInput("a", TypingMode.UNICODE))
        assertEquals("B\u2060", UnicodeProcessor.processInput("B", TypingMode.UNICODE))
        assertEquals("q\u2060", UnicodeProcessor.processInput("q", TypingMode.UNICODE))

        // Numbers, punctuation, spaces must NOT get U+2060
        assertEquals("5", UnicodeProcessor.processInput("5", TypingMode.UNICODE))
        assertEquals(".", UnicodeProcessor.processInput(".", TypingMode.UNICODE))
        assertEquals(",", UnicodeProcessor.processInput(",", TypingMode.UNICODE))
        assertEquals(" ", UnicodeProcessor.processInput(" ", TypingMode.UNICODE))
    }

    @Test
    fun unicodeMode_avoidsDuplicateJoinerAfterCursor() {
        assertEquals("a", UnicodeProcessor.processInput("a", TypingMode.UNICODE, "\u2060bc"))
        assertEquals("a\u2060b\u2060", UnicodeProcessor.processInput("a\u2060b", TypingMode.UNICODE))
    }

    @Test
    fun smartBackspace_deletesLetterAndWordJoinerTogether() {
        assertEquals(2, UnicodeProcessor.computeSmartBackspaceLength("a\u2060"))
        assertEquals(2, UnicodeProcessor.computeSmartBackspaceLength("helloQ\u2060"))
    }

    @Test
    fun smartBackspace_handlesNormalCharsSurrogatePairsAndEmojis() {
        assertEquals(0, UnicodeProcessor.computeSmartBackspaceLength(""))
        assertEquals(1, UnicodeProcessor.computeSmartBackspaceLength("abc"))
        assertEquals(1, UnicodeProcessor.computeSmartBackspaceLength("1\u2060"))
        // Surrogate pair emoji (😀 = \uD83D\uDE00)
        assertEquals(2, UnicodeProcessor.computeSmartBackspaceLength("hi 😀"))
        // Multi-codepoint ZWJ family emoji
        val family = "👨‍👩‍👧‍👦"
        assertEquals(family.length, UnicodeProcessor.computeSmartBackspaceLength("test $family"))
    }

    @Test
    fun stripWordJoiners_removesOnlyU2060() {
        assertEquals("hello", UnicodeProcessor.stripWordJoiners("h\u2060e\u2060l\u2060l\u2060o\u2060"))
    }
}
