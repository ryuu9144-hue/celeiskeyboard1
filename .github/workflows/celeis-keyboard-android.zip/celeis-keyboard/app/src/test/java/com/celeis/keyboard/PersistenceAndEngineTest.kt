package com.celeis.keyboard

import android.content.Context
import android.text.InputType
import android.view.inputmethod.EditorInfo
import androidx.test.core.app.ApplicationProvider
import com.celeis.keyboard.input.ShiftState
import com.celeis.keyboard.input.TextEditingEngine
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.privacy.SensitiveFieldDetector
import com.celeis.keyboard.themes.BuiltInThemes
import com.celeis.keyboard.themes.ThemeManager
import com.celeis.keyboard.unicode.TypingMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class PersistenceAndEngineTest {

    private lateinit var context: Context
    private lateinit var prefs: CeleisPreferences

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        prefs = CeleisPreferences(context)
        prefs.resetAllToDefaults()
    }

    @Test
    fun settingsAndMode_persistAcrossInstances() {
        prefs.typingMode = TypingMode.UNICODE
        prefs.keypressDelayMs = 250
        prefs.portraitHeightDp = 310

        val reloaded = CeleisPreferences(context)
        assertEquals(TypingMode.UNICODE, reloaded.typingMode)
        assertEquals(250, reloaded.keypressDelayMs)
        assertEquals(310, reloaded.portraitHeightDp)
    }

    @Test
    fun themeManager_persistsCustomAndBuiltInThemes() {
        val tm = ThemeManager(context, prefs)
        assertEquals(BuiltInThemes.CELEIS_DEFAULT_DARK.id, tm.getActiveTheme().id)

        val custom = tm.saveCustomTheme(
            BuiltInThemes.DARK.copy(id = "", name = "Test Custom", isBuiltIn = false)
        )
        tm.setActiveTheme(custom.id)

        val reloadedTm = ThemeManager(context, CeleisPreferences(context))
        assertEquals(custom.id, reloadedTm.getActiveTheme().id)

        reloadedTm.deleteCustomTheme(custom.id)
        assertEquals(BuiltInThemes.CELEIS_DEFAULT_DARK.id, reloadedTm.getActiveTheme().id)
    }

    @Test
    fun capsLock_persistsAcrossEngineRecreation() {
        val engine1 = TextEditingEngine(prefs)
        engine1.onShiftTap(100L)
        val state = engine1.onShiftTap(250L)
        assertEquals(ShiftState.CAPS_LOCK, state)
        assertTrue(prefs.persistentCapsLock)

        val engine2 = TextEditingEngine(CeleisPreferences(context))
        assertEquals(ShiftState.CAPS_LOCK, engine2.shiftState)
    }

    @Test
    fun sensitiveFieldDetector_identifiesPasswordsAndNoLearning() {
        val pw = EditorInfo().apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        assertTrue(SensitiveFieldDetector.isSensitiveField(pw))

        val normal = EditorInfo().apply {
            inputType = InputType.TYPE_CLASS_TEXT
        }
        assertFalse(SensitiveFieldDetector.isSensitiveField(normal))
    }
}
