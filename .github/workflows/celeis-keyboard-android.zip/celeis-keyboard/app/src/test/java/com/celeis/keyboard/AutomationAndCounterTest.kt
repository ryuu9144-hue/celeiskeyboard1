package com.celeis.keyboard.automation

import com.celeis.keyboard.prefs.CounterMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AutomationAndCounterTest {

    @Test
    fun numericCounter_formatsSequentially() {
        assertEquals("1", CounterFormatter.formatValue(CounterMode.NUMERIC, 1))
        assertEquals("42", CounterFormatter.formatValue(CounterMode.NUMERIC, 42))
    }

    @Test
    fun alphabeticCounter_rollsBeyondZCorrectly() {
        assertEquals("A", CounterFormatter.toAlphabetic(1))
        assertEquals("Z", CounterFormatter.toAlphabetic(26))
        assertEquals("AA", CounterFormatter.toAlphabetic(27))
        assertEquals("AB", CounterFormatter.toAlphabetic(28))
        assertEquals("AZ", CounterFormatter.toAlphabetic(52))
        assertEquals("BA", CounterFormatter.toAlphabetic(53))
        assertEquals("ZZ", CounterFormatter.toAlphabetic(702))
        assertEquals("AAA", CounterFormatter.toAlphabetic(703))
    }

    @Test
    fun parseAlphabeticStart_handlesValidAndInvalidInputs() {
        assertEquals(1L, CounterFormatter.parseAlphabeticStart("A"))
        assertEquals(27L, CounterFormatter.parseAlphabeticStart("aa"))
        assertEquals(1L, CounterFormatter.parseAlphabeticStart("123"))
    }

    @Test
    fun phraseCycler_cyclesUpToThreePhrases() {
        val cycler = PhraseCycler(listOf("One", "Two", "Three", "FourIgnored"))
        assertEquals(3, cycler.getPhrases().size)
        assertEquals("One", cycler.next())
        assertEquals("Two", cycler.next())
        assertEquals("Three", cycler.next())
        assertEquals("One", cycler.next())

        cycler.reset()
        assertEquals("One", cycler.next())

        cycler.setPhrases(emptyList())
        assertNull(cycler.next())
    }
}
