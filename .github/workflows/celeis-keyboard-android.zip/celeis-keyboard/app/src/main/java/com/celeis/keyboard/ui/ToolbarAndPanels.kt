package com.celeis.keyboard.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.celeis.keyboard.automation.AutoCounterController
import com.celeis.keyboard.automation.AutoPasteController
import com.celeis.keyboard.automation.AutomationState
import com.celeis.keyboard.automation.StoredPhrasesRepository
import com.celeis.keyboard.clipboard.ClipboardManagerStore
import com.celeis.keyboard.input.CursorDirection
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.prefs.CounterMode
import com.celeis.keyboard.prefs.OneHandedMode
import com.celeis.keyboard.themes.KeyboardTheme
import com.celeis.keyboard.unicode.TypingMode

enum class ActivePanel {
    KEYBOARD,
    EMOJI,
    FUNCTIONS,
    CLIPBOARD,
    PHRASES,
    AUTO_COUNTER,
    AUTOPASTE,
    RESIZE
}

/**
 * Top toolbar + suggestion strip for Celeis Keyboard.
 * Essential tools (Functions, Unicode/Normal switch, Clipboard, Themes, Settings)
 * remain directly accessible even when suggestions are shown.
 */
class ToolbarView(
    context: Context,
    private val onAction: (ToolbarAction) -> Unit,
    private val onSuggestionTap: (String) -> Unit
) : LinearLayout(context) {

    enum class ToolbarAction {
        FUNCTIONS,
        TOGGLE_UNICODE_MODE,
        CLIPBOARD,
        THEMES,
        EMOJI,
        ARROWS,
        AUTO_COUNTER,
        AUTOPASTE,
        STORED_PHRASES,
        RESIZE,
        VOICE,
        SETTINGS
    }

    private val suggestionRow = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        visibility = View.GONE
    }

    private val toolsScroll = HorizontalScrollView(context).apply {
        isHorizontalScrollBarEnabled = false
    }
    private val toolsRow = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private lateinit var modeBtn: TextView

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density

        addView(suggestionRow, LayoutParams(LayoutParams.MATCH_PARENT, (34 * d).toInt()))
        toolsScroll.addView(toolsRow)
        addView(toolsScroll, LayoutParams(LayoutParams.MATCH_PARENT, (40 * d).toInt()))

        buildTools()
    }

    private fun buildTools() {
        toolsRow.removeAllViews()
        addToolButton("⊞", "Functions", ToolbarAction.FUNCTIONS)
        modeBtn = addToolButton("ABC", "Mode", ToolbarAction.TOGGLE_UNICODE_MODE)
        addToolButton("📋", "Clipboard", ToolbarAction.CLIPBOARD)
        addToolButton("🎨", "Themes", ToolbarAction.THEMES)
        addToolButton("☺", "Emoji", ToolbarAction.EMOJI)
        addToolButton("✥", "Arrows", ToolbarAction.ARROWS)
        addToolButton("#", "Counter", ToolbarAction.AUTO_COUNTER)
        addToolButton("⚡", "AutoPaste", ToolbarAction.AUTOPASTE)
        addToolButton("💬", "Phrases", ToolbarAction.STORED_PHRASES)
        addToolButton("⤢", "Resize", ToolbarAction.RESIZE)
        addToolButton("🎙", "Voice", ToolbarAction.VOICE)
        addToolButton("⚙", "Settings", ToolbarAction.SETTINGS)
    }

    private fun addToolButton(icon: String, contentDesc: String, action: ToolbarAction): TextView {
        val d = resources.displayMetrics.density
        val tv = TextView(context).apply {
            text = icon
            contentDescription = contentDesc
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding((11 * d).toInt(), (6 * d).toInt(), (11 * d).toInt(), (6 * d).toInt())
            setOnClickListener { onAction(action) }
        }
        toolsRow.addView(tv)
        return tv
    }

    fun updateModeBadge(mode: TypingMode, theme: KeyboardTheme) {
        if (mode == TypingMode.UNICODE) {
            modeBtn.text = "U+2060"
            modeBtn.setTextColor(theme.accentColor)
        } else {
            modeBtn.text = "ABC"
            modeBtn.setTextColor(theme.keyTextColor)
        }
    }

    fun updateSuggestions(suggestions: List<String>, theme: KeyboardTheme) {
        suggestionRow.removeAllViews()
        if (suggestions.isEmpty()) {
            suggestionRow.visibility = View.GONE
            return
        }
        suggestionRow.visibility = View.VISIBLE
        suggestionRow.setBackgroundColor(theme.toolbarBackgroundColor)
        for (word in suggestions) {
            val tv = TextView(context).apply {
                text = word
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(theme.keyTextColor)
                setPadding(16, 6, 16, 6)
                setOnClickListener { onSuggestionTap(word) }
            }
            suggestionRow.addView(tv, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
        }
    }

    fun applyTheme(theme: KeyboardTheme, mode: TypingMode) {
        setBackgroundColor(theme.toolbarBackgroundColor)
        for (i in 0 until toolsRow.childCount) {
            val child = toolsRow.getChildAt(i) as? TextView ?: continue
            child.setTextColor(theme.keyTextColor)
        }
        updateModeBadge(mode, theme)
    }
}

/**
 * Dedicated Functions & Arrow-Key Navigation panel.
 */
class FunctionsPanelView(
    context: Context,
    private val prefs: CeleisPreferences,
    private val onMoveCursor: (CursorDirection) -> Unit,
    private val onOpenPanel: (ActivePanel) -> Unit,
    private val onToggleUnicodeMode: () -> Unit,
    private val onOpenThemesSettings: () -> Unit,
    private val onOpenSettings: () -> Unit,
    private val onToggleOneHanded: () -> Unit,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density
        val pad = (10 * d).toInt()
        setPadding(pad, pad, pad, pad)

        // Arrow navigation pad
        val arrowTitle = TextView(context).apply {
            text = "Cursor Navigation"
            textSize = 12f
            setTextColor(0xFF9BA6BC.toInt())
        }
        addView(arrowTitle)

        val arrowRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        val arrows = listOf(
            "←" to CursorDirection.LEFT,
            "↑" to CursorDirection.UP,
            "↓" to CursorDirection.DOWN,
            "→" to CursorDirection.RIGHT
        )
        for ((label, dir) in arrows) {
            val btn = Button(context).apply {
                text = label
                textSize = 18f
                setOnClickListener { onMoveCursor(dir) }
            }
            arrowRow.addView(btn, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        }
        addView(arrowRow)

        val gridScroll = ScrollView(context)
        val grid = LinearLayout(context).apply { orientation = VERTICAL }

        fun addRow(items: List<Pair<String, () -> Unit>>) {
            val row = LinearLayout(context).apply { orientation = HORIZONTAL }
            for ((label, action) in items) {
                val b = Button(context).apply {
                    text = label
                    textSize = 12f
                    setOnClickListener { action() }
                }
                row.addView(b, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            }
            grid.addView(row)
        }

        addRow(
            listOf(
                "Clipboard" to { onOpenPanel(ActivePanel.CLIPBOARD) },
                "Stored Phrases" to { onOpenPanel(ActivePanel.PHRASES) },
                "Themes" to { onOpenThemesSettings() }
            )
        )
        addRow(
            listOf(
                "Auto Counter" to { onOpenPanel(ActivePanel.AUTO_COUNTER) },
                "AutoPaste" to { onOpenPanel(ActivePanel.AUTOPASTE) },
                "Unicode Mode" to { onToggleUnicodeMode() }
            )
        )
        addRow(
            listOf(
                "Resize" to { onOpenPanel(ActivePanel.RESIZE) },
                "One-Handed (${prefs.oneHandedMode.name})" to { onToggleOneHanded() },
                "Settings" to { onOpenSettings() }
            )
        )

        gridScroll.addView(grid)
        addView(gridScroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        val backBtn = Button(context).apply {
            text = "Back to Keyboard (ABC)"
            setOnClickListener { onBackToAbc() }
        }
        addView(backBtn, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
    }
}

/**
 * Clipboard Manager Panel inside the IME.
 */
class ClipboardPanelView(
    context: Context,
    private val store: ClipboardManagerStore,
    private val onInsertText: (String) -> Unit,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    private val listContainer = LinearLayout(context).apply { orientation = VERTICAL }
    private val statusBanner = TextView(context).apply {
        textSize = 12f
        setPadding(12, 8, 12, 8)
        visibility = View.GONE
    }

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density
        setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())

        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(context).apply {
            text = "Clipboard"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val clearBtn = Button(context).apply {
            text = "Clear"
            textSize = 12f
            setOnClickListener {
                store.clearAll(keepPinned = true)
                refresh()
            }
        }
        val backBtn = Button(context).apply {
            text = "ABC"
            textSize = 12f
            setOnClickListener { onBackToAbc() }
        }
        header.addView(title, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(clearBtn)
        header.addView(backBtn)
        addView(header)
        addView(statusBanner)

        val scroll = ScrollView(context)
        scroll.addView(listContainer)
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    fun refresh(isSensitive: Boolean = store.isSensitiveContext) {
        listContainer.removeAllViews()
        if (isSensitive) {
            statusBanner.visibility = View.VISIBLE
            statusBanner.text = "Clipboard capture is paused in password/sensitive fields."
            statusBanner.setTextColor(0xFFFBBF24.toInt())
        } else {
            statusBanner.visibility = View.GONE
        }

        val items = store.getItems()
        if (items.isEmpty()) {
            val empty = TextView(context).apply {
                text = "No copied clips yet."
                setTextColor(0xFF9BA6BC.toInt())
                setPadding(16, 24, 16, 24)
            }
            listContainer.addView(empty)
            return
        }

        for (item in items) {
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 8, 8, 8)
            }
            val textTv = TextView(context).apply {
                text = (if (item.isPinned) "📌 " else "") + item.text
                maxLines = 2
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener { onInsertText(item.text) }
            }
            val pinBtn = Button(context).apply {
                text = if (item.isPinned) "Unpin" else "Pin"
                textSize = 11f
                setOnClickListener {
                    store.togglePin(item.id)
                    refresh(isSensitive)
                }
            }
            val delBtn = Button(context).apply {
                text = "✕"
                textSize = 11f
                setOnClickListener {
                    store.deleteItem(item.id)
                    refresh(isSensitive)
                }
            }
            row.addView(textTv, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(pinBtn)
            row.addView(delBtn)
            listContainer.addView(row)
        }
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
    }
}

/**
 * Stored Phrases Panel inside the IME.
 */
class StoredPhrasesPanelView(
    context: Context,
    private val repo: StoredPhrasesRepository,
    private val onInsertPhrase: (String) -> Unit,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    private val listContainer = LinearLayout(context).apply { orientation = VERTICAL }
    private val inputField = EditText(context).apply {
        hint = "Add phrase..."
        textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF9BA6BC.toInt())
    }

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density
        setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())

        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(context).apply {
            text = "Stored Phrases"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val cycleBtn = Button(context).apply {
            text = "Cycle Next"
            textSize = 11f
            setOnClickListener {
                repo.nextCyclePhrase()?.let { onInsertPhrase(it.text) }
            }
        }
        val backBtn = Button(context).apply {
            text = "ABC"
            textSize = 11f
            setOnClickListener { onBackToAbc() }
        }
        header.addView(title, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(cycleBtn)
        header.addView(backBtn)
        addView(header)

        val addRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        val addBtn = Button(context).apply {
            text = "Add"
            textSize = 12f
            setOnClickListener {
                val txt = inputField.text.toString().trim()
                if (txt.isNotEmpty()) {
                    repo.addPhrase(txt)
                    inputField.setText("")
                    refresh()
                }
            }
        }
        addRow.addView(inputField, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addRow.addView(addBtn)
        addView(addRow)

        val scroll = ScrollView(context)
        scroll.addView(listContainer)
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        refresh()
    }

    fun refresh() {
        listContainer.removeAllViews()
        val phrases = repo.getPhrases()
        if (phrases.isEmpty()) {
            listContainer.addView(
                TextView(context).apply {
                    text = "No stored phrases yet."
                    setTextColor(0xFF9BA6BC.toInt())
                    setPadding(12, 20, 12, 20)
                }
            )
            return
        }
        for (p in phrases) {
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(context).apply {
                text = p.text
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(8, 10, 8, 10)
                setOnClickListener { onInsertPhrase(p.text) }
            }
            val del = Button(context).apply {
                text = "✕"
                textSize = 11f
                setOnClickListener {
                    repo.deletePhrase(p.id)
                    refresh()
                }
            }
            row.addView(tv, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(del)
            listContainer.addView(row)
        }
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
    }
}

/**
 * Auto Counter Panel inside the IME.
 */
class AutoCounterPanelView(
    context: Context,
    private val prefs: CeleisPreferences,
    private val controller: AutoCounterController,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    private val statusTv = TextView(context).apply {
        textSize = 13f
        setTextColor(0xFF9BA6BC.toInt())
    }
    private val startInput = EditText(context).apply {
        hint = "Start (e.g. 1 or A)"
        setText(prefs.counterStartValue)
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF9BA6BC.toInt())
    }
    private val intervalInput = EditText(context).apply {
        hint = "Interval ms (e.g. 1000)"
        setText(prefs.counterIntervalMs.toString())
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF9BA6BC.toInt())
    }

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density
        setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())

        val header = LinearLayout(context).apply { orientation = HORIZONTAL }
        val title = TextView(context).apply {
            text = "Auto Counter"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val backBtn = Button(context).apply {
            text = "ABC"
            setOnClickListener { onBackToAbc() }
        }
        header.addView(title, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(backBtn)
        addView(header)
        addView(statusTv)

        val modeRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        val numBtn = Button(context).apply {
            text = "Numeric (1,2,3)"
            textSize = 11f
            setOnClickListener {
                prefs.counterMode = CounterMode.NUMERIC
                applyConfig()
            }
        }
        val alphaBtn = Button(context).apply {
            text = "Alphabetic (A..Z, AA)"
            textSize = 11f
            setOnClickListener {
                prefs.counterMode = CounterMode.ALPHABETIC
                applyConfig()
            }
        }
        modeRow.addView(numBtn, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        modeRow.addView(alphaBtn, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(modeRow)

        val cfgRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        cfgRow.addView(startInput, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        cfgRow.addView(intervalInput, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(cfgRow)

        val ctrlRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        ctrlRow.addView(Button(context).apply {
            text = "Start"
            textSize = 11f
            setOnClickListener {
                applyConfig()
                controller.start()
            }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        ctrlRow.addView(Button(context).apply {
            text = "Pause"
            textSize = 11f
            setOnClickListener {
                if (controller.state == AutomationState.PAUSED) controller.resume() else controller.pause()
            }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        ctrlRow.addView(Button(context).apply {
            text = "Stop"
            textSize = 11f
            setOnClickListener { controller.stop() }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        ctrlRow.addView(Button(context).apply {
            text = "Reset"
            textSize = 11f
            setOnClickListener {
                applyConfig()
                controller.reset()
            }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(ctrlRow)

        updateStatus(controller.state, controller.previewNext())
    }

    private fun applyConfig() {
        val start = startInput.text.toString().ifBlank { "1" }
        val interval = intervalInput.text.toString().toIntOrNull() ?: 1000
        prefs.counterStartValue = start
        prefs.counterIntervalMs = interval
        controller.configure(prefs.counterMode, start, interval.toLong())
    }

    fun updateStatus(state: AutomationState, nextVal: String) {
        statusTv.text = "Mode: ${prefs.counterMode.name} | State: ${state.name} | Next: $nextVal"
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
    }
}

/**
 * AutoPaste Panel inside the IME (1-3 phrases, focused-field insertion only).
 */
class AutoPastePanelView(
    context: Context,
    private val prefs: CeleisPreferences,
    private val controller: AutoPasteController,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    private val p1 = EditText(context).apply { hint = "Phrase 1"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9BA6BC.toInt()) }
    private val p2 = EditText(context).apply { hint = "Phrase 2 (optional)"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9BA6BC.toInt()) }
    private val p3 = EditText(context).apply { hint = "Phrase 3 (optional)"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9BA6BC.toInt()) }
    private val intervalEt = EditText(context).apply {
        hint = "Interval ms"
        setText(prefs.autoPasteIntervalMs.toString())
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF9BA6BC.toInt())
    }
    private val statusTv = TextView(context).apply {
        textSize = 12f
        setTextColor(0xFF9BA6BC.toInt())
    }

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density
        setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())

        val header = LinearLayout(context).apply { orientation = HORIZONTAL }
        header.addView(TextView(context).apply {
            text = "AutoPaste (1-3 Phrases)"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(context).apply {
            text = "ABC"
            setOnClickListener { onBackToAbc() }
        })
        addView(header)
        addView(statusTv)

        val scroll = ScrollView(context)
        val fields = LinearLayout(context).apply { orientation = VERTICAL }
        fields.addView(p1)
        fields.addView(p2)
        fields.addView(p3)
        fields.addView(intervalEt)
        scroll.addView(fields)
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        val ctrlRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        ctrlRow.addView(Button(context).apply {
            text = "Start"
            textSize = 11f
            setOnClickListener {
                saveInputs()
                controller.start(prefs.autoPasteIntervalMs.toLong())
            }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        ctrlRow.addView(Button(context).apply {
            text = "Pause"
            textSize = 11f
            setOnClickListener {
                if (controller.state == AutomationState.PAUSED) controller.resume() else controller.pause()
            }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        ctrlRow.addView(Button(context).apply {
            text = "Stop"
            textSize = 11f
            setOnClickListener { controller.stop() }
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(ctrlRow)

        refreshFields()
    }

    fun refreshFields() {
        val list = controller.getPhrases()
        p1.setText(list.getOrElse(0) { "" })
        p2.setText(list.getOrElse(1) { "" })
        p3.setText(list.getOrElse(2) { "" })
        updateStatus(controller.state)
    }

    private fun saveInputs() {
        val phrases = listOf(p1.text.toString(), p2.text.toString(), p3.text.toString())
        controller.savePhrases(phrases)
        prefs.autoPasteIntervalMs = intervalEt.text.toString().toIntOrNull() ?: 1200
    }

    fun updateStatus(state: AutomationState) {
        statusTv.text = "State: ${state.name} • Inserts into focused field only (never sends)"
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
    }
}
