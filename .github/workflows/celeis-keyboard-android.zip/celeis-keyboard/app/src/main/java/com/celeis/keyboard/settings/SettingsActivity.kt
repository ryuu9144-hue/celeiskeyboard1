package com.celeis.keyboard.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.celeis.keyboard.BuildConfig
import com.celeis.keyboard.automation.StoredPhrasesRepository
import com.celeis.keyboard.clipboard.ClipboardManagerStore
import com.celeis.keyboard.dictionary.DictionaryEngine
import com.celeis.keyboard.emoji.EmojiHistoryStore
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.prefs.CounterMode
import com.celeis.keyboard.prefs.OneHandedMode
import com.celeis.keyboard.themes.BuiltInThemes
import com.celeis.keyboard.themes.KeyboardTheme
import com.celeis.keyboard.themes.ThemeManager
import com.celeis.keyboard.unicode.TypingMode
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Full 18-section Settings application for Celeis Keyboard,
 * including a persistent "Try out your setup" test bar at the bottom.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: CeleisPreferences
    private lateinit var themeManager: ThemeManager
    private lateinit var clipboardStore: ClipboardManagerStore
    private lateinit var emojiHistoryStore: EmojiHistoryStore
    private lateinit var phrasesRepo: StoredPhrasesRepository
    private lateinit var dictionary: DictionaryEngine

    private lateinit var scrollView: ScrollView
    private lateinit var container: LinearLayout
    private var themesSectionView: View? = null

    private var pendingCustomBgPath: String? = null
    private var pendingBgOpacity: Float = 0.75f

    private val photoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val imported = themeManager.importGalleryImage(uri)
            if (imported != null) {
                pendingCustomBgPath = imported
                showCreateCustomThemeDialog()
            } else {
                Toast.makeText(this, "Could not load selected image.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(
            this,
            if (granted) "Microphone permission granted." else "Microphone permission denied.",
            Toast.LENGTH_SHORT
        ).show()
        rebuildUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = CeleisPreferences(this)
        themeManager = ThemeManager(this, prefs)
        clipboardStore = ClipboardManagerStore(this, prefs)
        emojiHistoryStore = EmojiHistoryStore(this)
        phrasesRepo = StoredPhrasesRepository(this)
        dictionary = DictionaryEngine(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#111318"))
        }

        // Top App Bar
        val topBar = TextView(this).apply {
            text = "Celeis Keyboard Settings"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#181C24"))
            setPadding(40, 36, 40, 28)
        }
        root.addView(topBar)

        scrollView = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 32)
        }
        scrollView.addView(container)
        root.addView(scrollView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Persistent "Try out your setup" bar
        val tryBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1D222D"))
            setPadding(24, 14, 24, 14)
        }
        val tryInput = EditText(this).apply {
            hint = "Try out your setup"
            setHintTextColor(Color.parseColor("#9AA4B8"))
            setTextColor(Color.WHITE)
            background = null
            textSize = 15f
        }
        val pickerBtn = Button(this).apply {
            text = "⌨"
            textSize = 16f
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        tryBar.addView(tryInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tryBar.addView(pickerBtn)
        root.addView(tryBar)

        setContentView(root)
        rebuildUi()

        val targetSection = intent.getStringExtra(EXTRA_SECTION)
        if (targetSection == "themes") {
            scrollView.post {
                themesSectionView?.let { scrollView.smoothScrollTo(0, it.top) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        rebuildUi()
    }

    private fun rebuildUi() {
        container.removeAllViews()
        addImeSetupCard()
        addSection1General()
        addSection2Layout()
        addSection3HeightAndWidth()
        addSection4KeySpacing()
        addSection5KeyPress()
        addSection6SoundsAndVibration()
        addSection7Themes()
        addSection8Clipboard()
        addSection9Emoji()
        addSection10Dictionary()
        addSection11Languages()
        addSection12AutoCounter()
        addSection13AutoPaste()
        addSection14StoredPhrases()
        addSection15VoiceTyping()
        addSection16Privacy()
        addSection17Compatibility()
        addSection18About()
    }

    private fun addImeSetupCard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabledList = imm.enabledInputMethodList
        val isEnabled = enabledList.any { it.packageName == packageName }
        val defaultIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val isActive = defaultIme.contains(packageName)

        addSectionHeader("Setup & Activation")
        addInfoRow(
            title = "Status",
            subtitle = "Enabled: ${if (isEnabled) "Yes" else "No"} • Active: ${if (isActive) "Yes" else "No"}"
        )
        addButtonRow("1. Enable Celeis Keyboard in Android Settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        addButtonRow("2. Switch Active Keyboard to Celeis") {
            imm.showInputMethodPicker()
        }
    }

    private fun addSection1General() {
        addSectionHeader("1. General")
        addSwitchRow(
            title = "Unicode Mode (U+2060 WORD JOINER)",
            subtitle = "Append U+2060 after every English letter [A-Za-z] with Smart Backspace",
            checked = prefs.typingMode == TypingMode.UNICODE
        ) { checked ->
            prefs.typingMode = if (checked) TypingMode.UNICODE else TypingMode.NORMAL
        }
        addSwitchRow(
            title = "Sentence capitalization",
            subtitle = "Capitalize first letter of each sentence",
            checked = prefs.sentenceCapitalization
        ) { prefs.sentenceCapitalization = it }
        addSwitchRow(
            title = "Persistent Caps Lock",
            subtitle = "Keep Caps Lock active across keyboard close and app switching",
            checked = prefs.persistentCapsLock
        ) { prefs.persistentCapsLock = it }
    }

    private fun addSection2Layout() {
        addSectionHeader("2. Keyboard Layout")
        addSwitchRow("Dedicated number row", "Show 0–9 above QWERTY", prefs.showNumberRow) {
            prefs.showNumberRow = it
        }
        addSwitchRow("Number row in Symbols", "Keep 0–9 visible on Symbols pages", prefs.showNumberRowInSymbols) {
            prefs.showNumberRowInSymbols = it
        }
        addSwitchRow("Long-press alternate characters", "Show accented letters and symbols on key hold", prefs.showAltCharacters) {
            prefs.showAltCharacters = it
        }
        addSwitchRow("Landscape fullscreen input", "Expand editor in landscape where supported", prefs.landscapeFullscreen) {
            prefs.landscapeFullscreen = it
        }
    }

    private fun addSection3HeightAndWidth() {
        addSectionHeader("3. Keyboard Height and Width")
        addSliderRow("Portrait height", prefs.portraitHeightDp, 180, 420, "dp") {
            prefs.portraitHeightDp = it
        }
        addSliderRow("Landscape height", prefs.landscapeHeightDp, 130, 300, "dp") {
            prefs.landscapeHeightDp = it
        }
        addSliderRow("Keyboard width", prefs.keyboardWidthPercent, 65, 100, "%") {
            prefs.keyboardWidthPercent = it
        }
        addSliderRow("Bottom offset", prefs.bottomOffsetDp, 0, 64, "dp") {
            prefs.bottomOffsetDp = it
        }
        addButtonRow("One-handed mode: ${prefs.oneHandedMode.name}") {
            prefs.oneHandedMode = when (prefs.oneHandedMode) {
                OneHandedMode.OFF -> OneHandedMode.RIGHT
                OneHandedMode.RIGHT -> OneHandedMode.LEFT
                OneHandedMode.LEFT -> OneHandedMode.OFF
            }
            rebuildUi()
        }
        addSliderRow("One-handed width", prefs.oneHandedWidthPercent, 65, 95, "%") {
            prefs.oneHandedWidthPercent = it
        }
        addButtonRow("Reset Height, Width & Spacing to Defaults") {
            prefs.resetSizeAndSpacingToDefaults()
            rebuildUi()
        }
    }

    private fun addSection4KeySpacing() {
        addSectionHeader("4. Key Spacing & Appearance")
        addSliderRow("Horizontal key spacing", prefs.horizontalKeySpacingDp, 0, 12, "dp") {
            prefs.horizontalKeySpacingDp = it
        }
        addSliderRow("Vertical key spacing", prefs.verticalKeySpacingDp, 0, 14, "dp") {
            prefs.verticalKeySpacingDp = it
        }
        addSliderRow("Key corner radius", prefs.keyCornerRadiusDp, 0, 20, "dp") {
            prefs.keyCornerRadiusDp = it
        }
        addSliderRow("Key border width", prefs.keyBorderWidthDp, 0, 3, "dp") {
            prefs.keyBorderWidthDp = it
        }
        addSliderRow("Key font size", prefs.keyFontSizeSp, 14, 28, "sp") {
            prefs.keyFontSizeSp = it
        }
    }

    private fun addSection5KeyPress() {
        addSectionHeader("5. Key Press")
        addSliderRow(
            title = "Keypress delay (repeat interval)",
            value = prefs.keypressDelayMs,
            min = 10,
            max = 1000,
            unit = "ms"
        ) { prefs.keypressDelayMs = it }
        addInfoRow(
            "What Keypress delay controls",
            "Sets the repeat interval (10–1000 ms) for held deletion/navigation without slowing single-tap typing."
        )
        addSliderRow("Key hold delay (long-press)", prefs.keyHoldDelayMs, 150, 1000, "ms") {
            prefs.keyHoldDelayMs = it
        }
        addSwitchRow("Popup visibility", "Show enlarged key preview popup on tap", prefs.showKeyPopups) {
            prefs.showKeyPopups = it
        }
    }

    private fun addSection6SoundsAndVibration() {
        addSectionHeader("6. Sounds and Vibration")
        addSwitchRow("Keypress sound", "Play system key click sound", prefs.soundOnKeypress) {
            prefs.soundOnKeypress = it
        }
        addSwitchRow("Haptic feedback", "Vibrate on keypress", prefs.hapticOnKeypress) {
            prefs.hapticOnKeypress = it
        }
        addSliderRow("Vibration intensity", prefs.hapticIntensity, 10, 100, "%") {
            prefs.hapticIntensity = it
        }
    }

    private fun addSection7Themes() {
        themesSectionView = addSectionHeader("7. Themes")
        val allThemes = themeManager.getAllThemes()
        val activeId = prefs.activeThemeId
        for (t in allThemes) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 14, 16, 14)
            }
            val swatch = View(this).apply {
                setBackgroundColor(t.enterKeyBackgroundColor)
            }
            val label = TextView(this).apply {
                text = if (t.id == activeId) "${t.name} (Active)" else t.name
                textSize = 15f
                setTextColor(if (t.id == activeId) Color.parseColor("#6C8EFF") else Color.WHITE)
                setPadding(24, 0, 16, 0)
                setOnClickListener {
                    themeManager.setActiveTheme(t.id)
                    rebuildUi()
                }
            }
            row.addView(swatch, LinearLayout.LayoutParams(48, 48))
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (!t.isBuiltIn) {
                val delBtn = Button(this).apply {
                    text = "Delete"
                    setOnClickListener {
                        themeManager.deleteCustomTheme(t.id)
                        rebuildUi()
                    }
                }
                row.addView(delBtn)
            }
            container.addView(row)
        }

        addButtonRow("Create Custom Theme from Gallery Image") {
            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }

    private fun showCreateCustomThemeDialog() {
        val nameEt = EditText(this).apply { hint = "Theme name (e.g. My Photo Theme)" }
        val opacitySeek = SeekBar(this).apply {
            max = 95
            progress = 70
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
            addView(nameEt)
            addView(TextView(this@SettingsActivity).apply { text = "Background Opacity"; setPadding(0, 16, 0, 8) })
            addView(opacitySeek)
        }
        AlertDialog.Builder(this)
            .setTitle("Save Custom Theme")
            .setView(layout)
            .setPositiveButton("Save & Apply") { _, _ ->
                pendingBgOpacity = (opacitySeek.progress + 5) / 100f
                val custom = BuiltInThemes.CELEIS_DEFAULT_DARK.copy(
                    id = "",
                    name = nameEt.text.toString().ifBlank { "Custom Gallery Theme" },
                    isBuiltIn = false,
                    backgroundImagePath = pendingCustomBgPath,
                    backgroundOpacity = pendingBgOpacity
                )
                val saved = themeManager.saveCustomTheme(custom)
                themeManager.setActiveTheme(saved.id)
                rebuildUi()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addSection8Clipboard() {
        addSectionHeader("8. Clipboard")
        addSwitchRow("Clipboard history", "Save recent copied clips locally (paused in sensitive fields)", prefs.clipboardEnabled) {
            prefs.clipboardEnabled = it
        }
        addSliderRow("Max clipboard items", prefs.clipboardMaxItems, 10, 100, "items") {
            prefs.clipboardMaxItems = it
        }
        addButtonRow("Clear All Clipboard History") {
            clipboardStore.clearAll(keepPinned = false)
            Toast.makeText(this, "Clipboard history cleared.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addSection9Emoji() {
        addSectionHeader("9. Emoji")
        addSwitchRow("Show emoji key", "Display dedicated emoji button on keyboard", prefs.showEmojiKey) {
            prefs.showEmojiKey = it
        }
        addButtonRow("Clear Recent & Frequent Emojis") {
            emojiHistoryStore.clear()
            Toast.makeText(this, "Emoji history cleared.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addSection10Dictionary() {
        addSectionHeader("10. Dictionary and Suggestions")
        addInfoRow("Manual Selection Only", "Autocorrect and swipe typing are disabled. Text is never changed automatically.")
        addSwitchRow("Show suggestion strip", "Display optional word suggestions above the keyboard", prefs.showSuggestions) {
            prefs.showSuggestions = it
        }
        addSwitchRow("Next-word suggestions", "Suggest likely next words after a space", prefs.nextWordSuggestions) {
            prefs.nextWordSuggestions = it
        }
        addButtonRow("Manage Personal Dictionary (${dictionary.getPersonalWords().size} words)") {
            showPersonalDictionaryDialog()
        }
    }

    private fun showPersonalDictionaryDialog() {
        val input = EditText(this).apply { hint = "Add custom word" }
        AlertDialog.Builder(this)
            .setTitle("Personal Dictionary")
            .setMessage("Current words: ${dictionary.getPersonalWords().joinToString(", ").ifEmpty { "None" }}")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                dictionary.addPersonalWord(input.text.toString())
                rebuildUi()
            }
            .setNeutralButton("Clear All") { _, _ ->
                dictionary.clearPersonalWords()
                rebuildUi()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun addSection11Languages() {
        addSectionHeader("11. Languages")
        addInfoRow("English (US / UK) — Fully Supported", "QWERTY layout, dictionary, suggestions, and Unicode U+2060 mode.")
        addButtonRow("Active Layout: ${prefs.activeLanguageCode}") {
            prefs.activeLanguageCode = if (prefs.activeLanguageCode == "en_US") "en_GB" else "en_US"
            rebuildUi()
        }
    }

    private fun addSection12AutoCounter() {
        addSectionHeader("12. Auto Counter")
        addButtonRow("Counter Mode: ${prefs.counterMode.name}") {
            prefs.counterMode = if (prefs.counterMode == CounterMode.NUMERIC) CounterMode.ALPHABETIC else CounterMode.NUMERIC
            rebuildUi()
        }
        addSliderRow("Counter interval", prefs.counterIntervalMs, 200, 10000, "ms") {
            prefs.counterIntervalMs = it
        }
    }

    private fun addSection13AutoPaste() {
        addSectionHeader("13. AutoPaste")
        addInfoRow("Safety Guarantee", "AutoPaste inserts 1–3 phrases into the focused field only and never presses Send.")
        addSliderRow("AutoPaste interval", prefs.autoPasteIntervalMs, 200, 10000, "ms") {
            prefs.autoPasteIntervalMs = it
        }
    }

    private fun addSection14StoredPhrases() {
        addSectionHeader("14. Stored Phrases")
        addInfoRow("Saved Phrases", "${phrasesRepo.getPhrases().size} local phrases stored.")
        addButtonRow("Add New Stored Phrase") {
            val et = EditText(this).apply { hint = "Enter phrase" }
            AlertDialog.Builder(this)
                .setTitle("Add Stored Phrase")
                .setView(et)
                .setPositiveButton("Save") { _, _ ->
                    phrasesRepo.addPhrase(et.text.toString())
                    rebuildUi()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun addSection15VoiceTyping() {
        addSectionHeader("15. Voice Typing")
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val serviceAvail = SpeechRecognizer.isRecognitionAvailable(this)

        addSwitchRow("Show microphone key", "Display voice typing button on bottom row", prefs.showVoiceKey) {
            prefs.showVoiceKey = it
        }
        addInfoRow(
            "Voice Recognition Status",
            "Mic Permission: ${if (hasMic) "Granted" else "Not Granted"} • Speech Service: ${if (serviceAvail) "Available" else "Unavailable"}"
        )
        if (!hasMic) {
            addButtonRow("Grant Microphone Permission") {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun addSection16Privacy() {
        addSectionHeader("16. Privacy")
        addInfoRow(
            "100% On-Device Privacy",
            "Celeis Keyboard requests zero INTERNET permission. Typed text, clipboard history, stored phrases, and custom themes remain strictly on your device. Suggestions, clipboard capture, and automation are automatically disabled in password and sensitive fields."
        )
        addButtonRow("Clear All Local Data & Reset Settings") {
            clipboardStore.clearAll(false)
            emojiHistoryStore.clear()
            phrasesRepo.clearAll()
            dictionary.clearPersonalWords()
            prefs.resetAllToDefaults()
            Toast.makeText(this, "All local data cleared.", Toast.LENGTH_SHORT).show()
            rebuildUi()
        }
    }

    private fun addSection17Compatibility() {
        addSectionHeader("17. Compatibility")
        val dm = resources.displayMetrics
        addInfoRow(
            "Device Diagnostics",
            "Device: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Screen: ${dm.widthPixels}x${dm.heightPixels}px @ ${dm.densityDpi}dpi (fontScale=${resources.configuration.fontScale})"
        )
    }

    private fun addSection18About() {
        addSectionHeader("18. About Celeis")
        addInfoRow(
            "Celeis Keyboard v${BuildConfig.VERSION_NAME}",
            "Native Kotlin Android IME featuring U+2060 WORD JOINER Unicode Mode, Smart Backspace, Persistent Caps Lock, customizable layouts, gallery themes, Clipboard, Stored Phrases, Auto Counter, and AutoPaste."
        )
    }

    private fun addSectionHeader(title: String): TextView {
        val tv = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.parseColor("#6C8EFF"))
            setPadding(8, 36, 8, 12)
        }
        container.addView(tv)
        return tv
    }

    private fun addInfoRow(title: String, subtitle: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 10, 8, 10)
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.parseColor("#9AA4B8"))
        })
        container.addView(box)
    }

    private fun addSwitchRow(title: String, subtitle: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 12, 8, 12)
        }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textCol.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(Color.WHITE) })
        textCol.addView(TextView(this).apply { text = subtitle; textSize = 12f; setTextColor(Color.parseColor("#9AA4B8")) })
        val sw = MaterialSwitch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, isChecked -> onChanged(isChecked) }
        }
        row.addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sw)
        container.addView(row)
    }

    private fun addSliderRow(title: String, value: Int, min: Int, max: Int, unit: String, onChanged: (Int) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 10, 8, 10)
        }
        val label = TextView(this).apply {
            text = "$title: $value $unit"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            this.progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = min + p
                    label.text = "$title: $v $unit"
                    onChanged(v)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        box.addView(label)
        box.addView(seek)
        container.addView(box)
    }

    private fun addButtonRow(text: String, onClick: () -> Unit) {
        val btn = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }
        container.addView(btn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 6, 0, 6)
        })
    }

    companion object {
        const val EXTRA_SECTION = "extra_section"
    }
}
