package com.celeis.keyboard.automation

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray

/**
 * Pure phrase cycler for 1 to 3 AutoPaste phrases.
 */
class PhraseCycler(initialPhrases: List<String> = emptyList()) {
    private val phrases = mutableListOf<String>()
    private var index = 0

    init {
        setPhrases(initialPhrases)
    }

    fun setPhrases(items: List<String>) {
        phrases.clear()
        items.map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(MAX_PHRASES)
            .forEach { phrases.add(it) }
        if (index >= phrases.size) index = 0
    }

    fun getPhrases(): List<String> = phrases.toList()

    fun next(): String? {
        if (phrases.isEmpty()) return null
        val value = phrases[index]
        index = (index + 1) % phrases.size
        return value
    }

    fun reset() {
        index = 0
    }

    companion object {
        const val MAX_PHRASES = 3
    }
}

/**
 * AutoPaste controller: cycles through 1 to 3 saved phrases and inserts them
 * ONLY into the focused text field. Never presses Send or transmits messages,
 * and stops immediately when focus is lost or a sensitive field is active.
 */
class AutoPasteController(
    context: Context,
    private val onInsertPhrase: (String) -> Unit,
    private val onStateChanged: (AutomationState) -> Unit
) {
    private val storePrefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val cycler = PhraseCycler(loadPhrases())

    var state: AutomationState = AutomationState.STOPPED
        private set

    var intervalMs: Long = 1200L

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (state != AutomationState.RUNNING) return
            val phrase = cycler.next()
            if (phrase != null) {
                onInsertPhrase(phrase)
                handler.postDelayed(this, intervalMs.coerceIn(200L, 10000L))
            } else {
                stop()
            }
        }
    }

    fun getPhrases(): List<String> = cycler.getPhrases()

    fun savePhrases(items: List<String>) {
        val clean = items.map { it.trim() }.filter { it.isNotEmpty() }.take(PhraseCycler.MAX_PHRASES)
        cycler.setPhrases(clean)
        val arr = JSONArray(clean)
        storePrefs.edit().putString(KEY_PHRASES, arr.toString()).apply()
    }

    fun start(intervalMs: Long) {
        if (cycler.getPhrases().isEmpty()) return
        this.intervalMs = intervalMs.coerceIn(200L, 10000L)
        handler.removeCallbacks(tickRunnable)
        cycler.reset()
        state = AutomationState.RUNNING
        onStateChanged(state)
        handler.post(tickRunnable)
    }

    fun pause() {
        if (state != AutomationState.RUNNING) return
        handler.removeCallbacks(tickRunnable)
        state = AutomationState.PAUSED
        onStateChanged(state)
    }

    fun resume() {
        if (state != AutomationState.PAUSED) return
        state = AutomationState.RUNNING
        onStateChanged(state)
        handler.post(tickRunnable)
    }

    fun stop() {
        handler.removeCallbacks(tickRunnable)
        state = AutomationState.STOPPED
        onStateChanged(state)
    }

    fun clearAll() {
        stop()
        savePhrases(emptyList())
    }

    private fun loadPhrases(): List<String> {
        val raw = storePrefs.getString(KEY_PHRASES, "[]") ?: "[]"
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    companion object {
        private const val PREFS_NAME = "celeis_autopaste_store"
        private const val KEY_PHRASES = "autopaste_phrases"
    }
}
