package com.celeis.keyboard.automation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class StoredPhrase(
    val id: String = UUID.randomUUID().toString(),
    val text: String
)

/**
 * Local repository for Stored Phrases: add, edit, delete, reorder, and cycle.
 */
class StoredPhrasesRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private var cycleIndex = 0

    fun getPhrases(): List<StoredPhrase> {
        val raw = prefs.getString(KEY_PHRASES, "[]") ?: "[]"
        val out = mutableListOf<StoredPhrase>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                out.add(StoredPhrase(obj.getString("id"), obj.getString("text")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addPhrase(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val list = getPhrases().toMutableList()
        list.add(StoredPhrase(text = t))
        save(list)
    }

    fun updatePhrase(id: String, newText: String) {
        val t = newText.trim()
        if (t.isEmpty()) return
        save(getPhrases().map { if (it.id == id) it.copy(text = t) else it })
    }

    fun deletePhrase(id: String) {
        save(getPhrases().filterNot { it.id == id })
    }

    fun movePhrase(fromIndex: Int, toIndex: Int) {
        val list = getPhrases().toMutableList()
        if (fromIndex !in list.indices || toIndex !in list.indices) return
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)
        save(list)
    }

    fun nextCyclePhrase(): StoredPhrase? {
        val list = getPhrases()
        if (list.isEmpty()) return null
        if (cycleIndex >= list.size) cycleIndex = 0
        val item = list[cycleIndex]
        cycleIndex = (cycleIndex + 1) % list.size
        return item
    }

    fun resetCycle() {
        cycleIndex = 0
    }

    fun clearAll() {
        save(emptyList())
        cycleIndex = 0
    }

    private fun save(list: List<StoredPhrase>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("text", p.text)
                }
            )
        }
        prefs.edit().putString(KEY_PHRASES, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "celeis_stored_phrases"
        private const val KEY_PHRASES = "phrases_json"
    }
}
