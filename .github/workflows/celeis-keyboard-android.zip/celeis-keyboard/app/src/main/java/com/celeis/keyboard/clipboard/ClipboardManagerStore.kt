package com.celeis.keyboard.clipboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import com.celeis.keyboard.prefs.CeleisPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ClipboardItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

/**
 * Local-only clipboard history manager.
 * Respects Android sensitive-clip flags and never captures while in password/sensitive fields.
 */
class ClipboardManagerStore(
    context: Context,
    private val prefs: CeleisPreferences
) {
    private val appContext = context.applicationContext
    private val storePrefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val systemClipboard =
        appContext.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    @Volatile
    var isSensitiveContext: Boolean = false

    private val listener = ClipboardManager.OnPrimaryClipChangedListener {
        if (!prefs.clipboardEnabled || isSensitiveContext) return@OnPrimaryClipChangedListener
        val cm = systemClipboard ?: return@OnPrimaryClipChangedListener
        val clip = cm.primaryClip ?: return@OnPrimaryClipChangedListener
        val desc = clip.description

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val isSensitive = desc?.extras?.getBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false) == true
            if (isSensitive) return@OnPrimaryClipChangedListener
        }

        if (clip.itemCount > 0) {
            val text = clip.getItemAt(0)?.coerceToText(appContext)?.toString()?.trim()
            if (!text.isNullOrEmpty()) {
                addClip(text)
            }
        }
    }

    fun startListening() {
        try {
            systemClipboard?.addPrimaryClipChangedListener(listener)
        } catch (_: Exception) {
        }
    }

    fun stopListening() {
        try {
            systemClipboard?.removePrimaryClipChangedListener(listener)
        } catch (_: Exception) {
        }
    }

    fun getItems(): List<ClipboardItem> {
        val raw = storePrefs.getString(KEY_ITEMS, "[]") ?: "[]"
        val list = mutableListOf<ClipboardItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    ClipboardItem(
                        id = obj.getString("id"),
                        text = obj.getString("text"),
                        timestampMs = obj.getLong("timestampMs"),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedWith(compareByDescending<ClipboardItem> { it.isPinned }.thenByDescending { it.timestampMs })
    }

    fun addClip(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val current = getItems().toMutableList()
        val existingIdx = current.indexOfFirst { it.text == trimmed }
        val wasPinned = if (existingIdx >= 0) current[existingIdx].isPinned else false
        if (existingIdx >= 0) {
            current.removeAt(existingIdx)
        }
        current.add(0, ClipboardItem(text = trimmed, isPinned = wasPinned))

        val maxItems = prefs.clipboardMaxItems
        val pinned = current.filter { it.isPinned }
        val unpinned = current.filterNot { it.isPinned }.take(maxItems)
        saveItems(pinned + unpinned)
    }

    fun togglePin(id: String) {
        val updated = getItems().map {
            if (it.id == id) it.copy(isPinned = !it.isPinned) else it
        }
        saveItems(updated)
    }

    fun deleteItem(id: String) {
        saveItems(getItems().filterNot { it.id == id })
    }

    fun clearAll(keepPinned: Boolean = false) {
        if (keepPinned) {
            saveItems(getItems().filter { it.isPinned })
        } else {
            saveItems(emptyList())
        }
    }

    private fun saveItems(items: List<ClipboardItem>) {
        val arr = JSONArray()
        for (item in items) {
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("text", item.text)
                    put("timestampMs", item.timestampMs)
                    put("isPinned", item.isPinned)
                }
            )
        }
        storePrefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "celeis_clipboard_store"
        private const val KEY_ITEMS = "clipboard_items"
    }
}
