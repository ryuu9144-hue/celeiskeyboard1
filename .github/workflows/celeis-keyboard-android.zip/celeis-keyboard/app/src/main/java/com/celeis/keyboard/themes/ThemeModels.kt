package com.celeis.keyboard.themes

import android.graphics.Color

data class KeyboardTheme(
    val id: String,
    val name: String,
    val isBuiltIn: Boolean = true,
    val backgroundColor: Int,
    val toolbarBackgroundColor: Int,
    val keyBackgroundColor: Int,
    val keyPressedColor: Int,
    val specialKeyBackgroundColor: Int,
    val enterKeyBackgroundColor: Int,
    val keyBorderColor: Int,
    val keyTextColor: Int,
    val keyHintTextColor: Int,
    val enterKeyTextColor: Int,
    val popupBackgroundColor: Int,
    val popupTextColor: Int,
    val accentColor: Int,
    val backgroundImagePath: String? = null,
    val backgroundOpacity: Float = 0.75f
)

object BuiltInThemes {

    val CELEIS_DEFAULT_DARK = KeyboardTheme(
        id = "celeis_default_dark",
        name = "Celeis Default Dark",
        backgroundColor = Color.parseColor("#0B0D14"),
        toolbarBackgroundColor = Color.parseColor("#111520"),
        keyBackgroundColor = Color.parseColor("#CC323746"),
        keyPressedColor = Color.parseColor("#EE4B5368"),
        specialKeyBackgroundColor = Color.parseColor("#CC1B1F2A"),
        enterKeyBackgroundColor = Color.parseColor("#5B9BFF"),
        keyBorderColor = Color.parseColor("#336C8EFF"),
        keyTextColor = Color.parseColor("#F5F7FA"),
        keyHintTextColor = Color.parseColor("#9BA6BC"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#2A3040"),
        popupTextColor = Color.parseColor("#FFFFFF"),
        accentColor = Color.parseColor("#5B9BFF")
    )

    val LIGHT = KeyboardTheme(
        id = "light",
        name = "Light",
        backgroundColor = Color.parseColor("#ECEFF4"),
        toolbarBackgroundColor = Color.parseColor("#E2E6EE"),
        keyBackgroundColor = Color.parseColor("#FFFFFF"),
        keyPressedColor = Color.parseColor("#DCE2EC"),
        specialKeyBackgroundColor = Color.parseColor("#D5DCE6"),
        enterKeyBackgroundColor = Color.parseColor("#2563EB"),
        keyBorderColor = Color.parseColor("#1A000000"),
        keyTextColor = Color.parseColor("#111827"),
        keyHintTextColor = Color.parseColor("#6B7280"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#FFFFFF"),
        popupTextColor = Color.parseColor("#111827"),
        accentColor = Color.parseColor("#2563EB")
    )

    val DARK = KeyboardTheme(
        id = "dark",
        name = "Dark",
        backgroundColor = Color.parseColor("#181A1F"),
        toolbarBackgroundColor = Color.parseColor("#1E2128"),
        keyBackgroundColor = Color.parseColor("#2B2F3A"),
        keyPressedColor = Color.parseColor("#3E4454"),
        specialKeyBackgroundColor = Color.parseColor("#22252E"),
        enterKeyBackgroundColor = Color.parseColor("#3B82F6"),
        keyBorderColor = Color.parseColor("#22FFFFFF"),
        keyTextColor = Color.parseColor("#F3F4F6"),
        keyHintTextColor = Color.parseColor("#9CA3AF"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#363B48"),
        popupTextColor = Color.parseColor("#FFFFFF"),
        accentColor = Color.parseColor("#3B82F6")
    )

    val DAY_MODE = KeyboardTheme(
        id = "day_mode",
        name = "Day Mode",
        backgroundColor = Color.parseColor("#F5F7FA"),
        toolbarBackgroundColor = Color.parseColor("#EAEEF5"),
        keyBackgroundColor = Color.parseColor("#FFFFFF"),
        keyPressedColor = Color.parseColor("#E0E7FF"),
        specialKeyBackgroundColor = Color.parseColor("#DDE4F0"),
        enterKeyBackgroundColor = Color.parseColor("#0EA5E9"),
        keyBorderColor = Color.parseColor("#14000000"),
        keyTextColor = Color.parseColor("#0F172A"),
        keyHintTextColor = Color.parseColor("#64748B"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#FFFFFF"),
        popupTextColor = Color.parseColor("#0F172A"),
        accentColor = Color.parseColor("#0EA5E9")
    )

    val NIGHT_MODE = KeyboardTheme(
        id = "night_mode",
        name = "Night Mode (AMOLED)",
        backgroundColor = Color.parseColor("#000000"),
        toolbarBackgroundColor = Color.parseColor("#08080A"),
        keyBackgroundColor = Color.parseColor("#16181D"),
        keyPressedColor = Color.parseColor("#2A2E38"),
        specialKeyBackgroundColor = Color.parseColor("#0E1014"),
        enterKeyBackgroundColor = Color.parseColor("#6366F1"),
        keyBorderColor = Color.parseColor("#26FFFFFF"),
        keyTextColor = Color.parseColor("#E2E8F0"),
        keyHintTextColor = Color.parseColor("#64748B"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#22252E"),
        popupTextColor = Color.parseColor("#FFFFFF"),
        accentColor = Color.parseColor("#6366F1")
    )

    val MIDNIGHT_VIOLET = KeyboardTheme(
        id = "midnight_violet",
        name = "Midnight Violet",
        backgroundColor = Color.parseColor("#120D21"),
        toolbarBackgroundColor = Color.parseColor("#19122E"),
        keyBackgroundColor = Color.parseColor("#CC2A2147"),
        keyPressedColor = Color.parseColor("#EE42356B"),
        specialKeyBackgroundColor = Color.parseColor("#CC1F1836"),
        enterKeyBackgroundColor = Color.parseColor("#8B5CF6"),
        keyBorderColor = Color.parseColor("#33A78BFA"),
        keyTextColor = Color.parseColor("#F5F3FF"),
        keyHintTextColor = Color.parseColor("#A78BFA"),
        enterKeyTextColor = Color.parseColor("#FFFFFF"),
        popupBackgroundColor = Color.parseColor("#352957"),
        popupTextColor = Color.parseColor("#FFFFFF"),
        accentColor = Color.parseColor("#A78BFA")
    )

    val EMERALD_SLATE = KeyboardTheme(
        id = "emerald_slate",
        name = "Emerald Slate",
        backgroundColor = Color.parseColor("#0C1917"),
        toolbarBackgroundColor = Color.parseColor("#11221F"),
        keyBackgroundColor = Color.parseColor("#CC1C332F"),
        keyPressedColor = Color.parseColor("#EE294B45"),
        specialKeyBackgroundColor = Color.parseColor("#CC152724"),
        enterKeyBackgroundColor = Color.parseColor("#10B981"),
        keyBorderColor = Color.parseColor("#3334D399"),
        keyTextColor = Color.parseColor("#ECFDF5"),
        keyHintTextColor = Color.parseColor("#6EE7B7"),
        enterKeyTextColor = Color.parseColor("#052E16"),
        popupBackgroundColor = Color.parseColor("#23413C"),
        popupTextColor = Color.parseColor("#ECFDF5"),
        accentColor = Color.parseColor("#10B981")
    )

    val ALL: List<KeyboardTheme> = listOf(
        CELEIS_DEFAULT_DARK,
        LIGHT,
        DARK,
        DAY_MODE,
        NIGHT_MODE,
        MIDNIGHT_VIOLET,
        EMERALD_SLATE
    )
}
