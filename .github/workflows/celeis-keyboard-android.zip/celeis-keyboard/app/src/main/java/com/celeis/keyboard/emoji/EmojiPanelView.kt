package com.celeis.keyboard.emoji

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.celeis.keyboard.themes.KeyboardTheme

/**
 * Full Emoji keyboard panel with categories, recent & frequent emojis,
 * search bar, easy insertion, and quick return to ABC.
 */
class EmojiPanelView(
    context: Context,
    private val historyStore: EmojiHistoryStore,
    private val onEmojiSelected: (String) -> Unit,
    private val onBackspace: () -> Unit,
    private val onBackToAbc: () -> Unit
) : LinearLayout(context) {

    private var activeCategory: EmojiCategory = EmojiCategory.SMILEYS
    private var displayedEmojis: List<String> = emptyList()
    private val adapter = EmojiGridAdapter()

    private val searchInput = EditText(context).apply {
        hint = "Search emojis..."
        textSize = 13f
        setSingleLine(true)
        setPadding(24, 12, 24, 12)
    }

    private val categoryBar = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private val recyclerView = RecyclerView(context).apply {
        layoutManager = GridLayoutManager(context, 8)
        adapter = this@EmojiPanelView.adapter
    }

    private val footerBar = LinearLayout(context).apply {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    init {
        orientation = VERTICAL
        val d = resources.displayMetrics.density

        addView(searchInput, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            setMargins((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        })

        val catScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryBar)
        }
        addView(catScroll, LayoutParams(LayoutParams.MATCH_PARENT, (40 * d).toInt()))

        addView(recyclerView, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        val abcBtn = Button(context).apply {
            text = "ABC"
            textSize = 13f
            setOnClickListener { onBackToAbc() }
        }
        val backspaceBtn = Button(context).apply {
            text = "⌫"
            textSize = 16f
            setOnClickListener { onBackspace() }
        }
        footerBar.addView(abcBtn, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        footerBar.addView(backspaceBtn, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(footerBar, LayoutParams(LayoutParams.MATCH_PARENT, (44 * d).toInt()))

        buildCategoryTabs()
        loadCategory(if (historyStore.getRecent().isNotEmpty()) EmojiCategory.RECENT else EmojiCategory.SMILEYS)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString().orEmpty()
                if (q.isBlank()) {
                    loadCategory(activeCategory)
                } else {
                    displayedEmojis = EmojiRepository.search(q).map { it.emoji }
                    adapter.notifyDataSetChanged()
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    fun applyTheme(theme: KeyboardTheme) {
        setBackgroundColor(theme.backgroundColor)
        searchInput.setTextColor(theme.keyTextColor)
        searchInput.setHintTextColor(theme.keyHintTextColor)
        searchInput.setBackgroundColor(theme.specialKeyBackgroundColor)
        categoryBar.setBackgroundColor(theme.toolbarBackgroundColor)
    }

    private fun buildCategoryTabs() {
        categoryBar.removeAllViews()
        val d = resources.displayMetrics.density
        for (cat in EmojiCategory.entries) {
            val tv = TextView(context).apply {
                text = cat.icon
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                setOnClickListener {
                    searchInput.setText("")
                    loadCategory(cat)
                }
            }
            categoryBar.addView(tv)
        }
    }

    fun loadCategory(category: EmojiCategory) {
        activeCategory = category
        displayedEmojis = if (category == EmojiCategory.RECENT) {
            (historyStore.getRecent() + historyStore.getFrequent()).distinct()
        } else {
            EmojiRepository.catalog[category].orEmpty().map { it.emoji }
        }
        adapter.notifyDataSetChanged()
    }

    private inner class EmojiGridAdapter : RecyclerView.Adapter<EmojiVH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmojiVH {
            val tv = TextView(parent.context).apply {
                textSize = 24f
                gravity = Gravity.CENTER
                setPadding(6, 10, 6, 10)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            return EmojiVH(tv)
        }

        override fun onBindViewHolder(holder: EmojiVH, position: Int) {
            val emoji = displayedEmojis[position]
            holder.tv.text = emoji
            holder.tv.setOnClickListener {
                historyStore.recordUsage(emoji)
                onEmojiSelected(emoji)
            }
        }

        override fun getItemCount(): Int = displayedEmojis.size
    }

    private class EmojiVH(val tv: TextView) : RecyclerView.ViewHolder(tv)
}
