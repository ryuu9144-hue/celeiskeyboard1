package com.celeis.keyboard.layout

import com.celeis.keyboard.prefs.OneHandedMode

data class KeyRect(
    val key: KeySpec,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    fun contains(x: Float, y: Float): Boolean = x in left..right && y in top..bottom
    fun centerX(): Float = (left + right) * 0.5f
    fun centerY(): Float = (top + bottom) * 0.5f
    fun width(): Float = right - left
    fun height(): Float = bottom - top
}

/**
 * Pure geometry calculator for keyboard key rectangles.
 * Supports adaptive screen widths, portrait/landscape heights,
 * horizontal/vertical spacing, and one-handed left/right alignment.
 */
object LayoutCalculator {

    fun computeKeyboardWidthPx(
        availableWidthPx: Float,
        widthPercent: Int,
        oneHandedMode: OneHandedMode,
        oneHandedWidthPercent: Int
    ): Float {
        val pct = if (oneHandedMode != OneHandedMode.OFF) {
            oneHandedWidthPercent.coerceIn(65, 95)
        } else {
            widthPercent.coerceIn(65, 100)
        }
        return availableWidthPx * (pct / 100f)
    }

    fun computeHorizontalOffsetPx(
        availableWidthPx: Float,
        keyboardWidthPx: Float,
        oneHandedMode: OneHandedMode
    ): Float {
        val slack = (availableWidthPx - keyboardWidthPx).coerceAtLeast(0f)
        return when (oneHandedMode) {
            OneHandedMode.OFF -> slack * 0.5f
            OneHandedMode.LEFT -> 0f
            OneHandedMode.RIGHT -> slack
        }
    }

    fun computeKeyRects(
        rows: List<List<KeySpec>>,
        availableWidthPx: Float,
        keyboardHeightPx: Float,
        widthPercent: Int,
        oneHandedMode: OneHandedMode,
        oneHandedWidthPercent: Int,
        hSpacingPx: Float,
        vSpacingPx: Float
    ): List<KeyRect> {
        if (rows.isEmpty() || availableWidthPx <= 0f || keyboardHeightPx <= 0f) {
            return emptyList()
        }

        val kbWidth = computeKeyboardWidthPx(
            availableWidthPx,
            widthPercent,
            oneHandedMode,
            oneHandedWidthPercent
        )
        val xStart = computeHorizontalOffsetPx(availableWidthPx, kbWidth, oneHandedMode)

        val rowCount = rows.size
        val totalVSpacing = vSpacingPx * (rowCount + 1)
        val rowHeight = ((keyboardHeightPx - totalVSpacing) / rowCount).coerceAtLeast(16f)

        val rects = ArrayList<KeyRect>(rowCount * 10)

        for (rowIdx in rows.indices) {
            val row = rows[rowIdx]
            val totalWeight = row.sumOf { it.weight.toDouble() }.toFloat().coerceAtLeast(1f)
            val usableWidth = (kbWidth - hSpacingPx * 2f).coerceAtLeast(1f)
            val top = vSpacingPx + rowIdx * (rowHeight + vSpacingPx)
            val bottom = top + rowHeight

            var cursorX = xStart + hSpacingPx
            for (key in row) {
                val cellWidth = usableWidth * (key.weight / totalWeight)
                if (key.type != KeyType.SPACER) {
                    val left = cursorX + hSpacingPx * 0.5f
                    val right = (cursorX + cellWidth - hSpacingPx * 0.5f).coerceAtLeast(left + 4f)
                    rects.add(KeyRect(key, left, top, right, bottom))
                }
                cursorX += cellWidth
            }
        }
        return rects
    }
}
