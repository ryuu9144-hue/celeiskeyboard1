package com.celeis.keyboard.themes

import android.content.Context
import android.net.Uri
import com.celeis.keyboard.prefs.CeleisPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Manages built-in and user-created custom themes (including gallery image backgrounds).
 * Custom theme images are copied into app-private internal storage via ContentResolver
 * so no storage permissions are needed and themes persist reliably.
 */
class ThemeManager(
    private val context: Context,
    private val prefs: CeleisPreferences
) {
    private val appContext = context.applicationContext

    fun getAllThemes(): List<KeyboardTheme> {
        return BuiltInThemes.ALL + getCustomThemes()
    }

    fun getActiveTheme(): KeyboardTheme {
        val activeId = prefs.activeThemeId
        return getAllThemes().firstOrNull { it.id == activeId }
            ?: BuiltInThemes.CELEIS_DEFAULT_DARK
    }

    fun setActiveTheme(themeId: String) {
        prefs.activeThemeId = themeId
    }

    fun getCustomThemes(): List<KeyboardTheme> {
        val raw = prefs.prefs.getString(KEY_CUSTOM_THEMES, "[]") ?: "[]"
        val result = mutableListOf<KeyboardTheme>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    KeyboardTheme(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        isBuiltIn = false,
                        backgroundColor = obj.getInt("backgroundColor"),
                        toolbarBackgroundColor = obj.getInt("toolbarBackgroundColor"),
                        keyBackgroundColor = obj.getInt("keyBackgroundColor"),
                        keyPressedColor = obj.getInt("keyPressedColor"),
                        specialKeyBackgroundColor = obj.getInt("specialKeyBackgroundColor"),
                        enterKeyBackgroundColor = obj.getInt("enterKeyBackgroundColor"),
                        keyBorderColor = obj.getInt("keyBorderColor"),
                        keyTextColor = obj.getInt("keyTextColor"),
                        keyHintTextColor = obj.getInt("keyHintTextColor"),
                        enterKeyTextColor = obj.getInt("enterKeyTextColor"),
                        popupBackgroundColor = obj.getInt("popupBackgroundColor"),
                        popupTextColor = obj.getInt("popupTextColor"),
                        accentColor = obj.getInt("accentColor"),
                        backgroundImagePath = obj.optString("backgroundImagePath").ifEmpty { null },
                        backgroundOpacity = obj.optDouble("backgroundOpacity", 0.75).toFloat()
                    )
                )
            }
        } catch (_: Exception) {
        }
        return result
    }

    fun saveCustomTheme(theme: KeyboardTheme): KeyboardTheme {
        val id = if (theme.id.isBlank() || theme.isBuiltIn) {
            "custom_${UUID.randomUUID().toString().take(8)}"
        } else {
            theme.id
        }
        val savedTheme = theme.copy(id = id, isBuiltIn = false)
        val current = getCustomThemes().filterNot { it.id == id }.toMutableList()
        current.add(savedTheme)
        persistCustomThemes(current)
        return savedTheme
    }

    fun deleteCustomTheme(themeId: String) {
        val existing = getCustomThemes()
        val toDelete = existing.firstOrNull { it.id == themeId }
        if (toDelete?.backgroundImagePath != null) {
            try {
                File(toDelete.backgroundImagePath).delete()
            } catch (_: Exception) {
            }
        }
        val updated = existing.filterNot { it.id == themeId }
        persistCustomThemes(updated)
        if (prefs.activeThemeId == themeId) {
            prefs.activeThemeId = CeleisPreferences.DEFAULT_THEME_ID
        }
    }

    /**
     * Copies a gallery image selected via Android's System Photo Picker into private app storage.
     */
    fun importGalleryImage(uri: Uri): String? {
        return try {
            val dir = File(appContext.filesDir, "theme_backgrounds").apply { mkdirs() }
            val outFile = File(dir, "bg_${System.currentTimeMillis()}.jpg")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
            outFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    private fun persistCustomThemes(themes: List<KeyboardTheme>) {
        val arr = JSONArray()
        for (t in themes) {
            val obj = JSONObject().apply {
                put("id", t.id)
                put("name", t.name)
                put("backgroundColor", t.backgroundColor)
                put("toolbarBackgroundColor", t.toolbarBackgroundColor)
                put("keyBackgroundColor", t.keyBackgroundColor)
                put("keyPressedColor", t.keyPressedColor)
                put("specialKeyBackgroundColor", t.specialKeyBackgroundColor)
                put("enterKeyBackgroundColor", t.enterKeyBackgroundColor)
                put("keyBorderColor", t.keyBorderColor)
                put("keyTextColor", t.keyTextColor)
                put("keyHintTextColor", t.keyHintTextColor)
                put("enterKeyTextColor", t.enterKeyTextColor)
                put("popupBackgroundColor", t.popupBackgroundColor)
                put("popupTextColor", t.popupTextColor)
                put("accentColor", t.accentColor)
                put("backgroundImagePath", t.backgroundImagePath ?: "")
                put("backgroundOpacity", t.backgroundOpacity.toDouble())
            }
            arr.put(obj)
        }
        prefs.prefs.edit().putString(KEY_CUSTOM_THEMES, arr.toString()).apply()
    }

    companion object {
        private const val KEY_CUSTOM_THEMES = "custom_themes_json"
    }
}
