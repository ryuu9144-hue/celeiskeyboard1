package com.celeis.keyboard.render

import android.content.Context
import android.content.res.Configuration
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.celeis.keyboard.prefs.CeleisPreferences

/**
 * Gboard-inspired live resizing overlay allowing immediate height and width adjustments
 * with a Reset-to-Default button and Done button.
 */
class ResizeOverlayView(
    context: Context,
    private val prefs: CeleisPreferences,
    private val onSizeChanged: () -> Unit,
    private val onDone: () -> Unit
) : LinearLayout(context) {

    private val isLandscape: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private val heightLabel = TextView(context).apply { textSize = 13f }
    private val widthLabel = TextView(context).apply { textSize = 13f }

    init {
        orientation = VERTICAL
        setBackgroundColor(0xE6111520.toInt())
        val d = resources.displayMetrics.density
        val pad = (14 * d).toInt()
        setPadding(pad, pad, pad, pad)

        val title = TextView(context).apply {
            text = "Resize Keyboard (Live)"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
        }
        addView(title)

        heightLabel.setTextColor(0xFF9BA6BC.toInt())
        addView(heightLabel)

        val currentHeight = if (isLandscape) prefs.landscapeHeightDp else prefs.portraitHeightDp
        val minH = if (isLandscape) 130 else 180
        val maxH = if (isLandscape) 300 else 420
        val heightSeek = SeekBar(context).apply {
            max = maxH - minH
            progress = (currentHeight - minH).coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = minH + p
                    if (isLandscape) {
                        prefs.landscapeHeightDp = value
                    } else {
                        prefs.portraitHeightDp = value
                    }
                    updateLabels()
                    onSizeChanged()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        addView(heightSeek)

        widthLabel.setTextColor(0xFF9BA6BC.toInt())
        addView(widthLabel)

        val widthSeek = SeekBar(context).apply {
            max = 35 // 65%..100%
            progress = (prefs.keyboardWidthPercent - 65).coerceIn(0, 35)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.keyboardWidthPercent = 65 + p
                    updateLabels()
                    onSizeChanged()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        addView(widthSeek)

        val btnRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.END
        }
        val resetBtn = Button(context).apply {
            text = "Reset Default"
            setOnClickListener {
                prefs.resetSizeAndSpacingToDefaults()
                val h = if (isLandscape) prefs.landscapeHeightDp else prefs.portraitHeightDp
                heightSeek.progress = (h - minH).coerceIn(0, maxH - minH)
                widthSeek.progress = (prefs.keyboardWidthPercent - 65).coerceIn(0, 35)
                updateLabels()
                onSizeChanged()
            }
        }
        val doneBtn = Button(context).apply {
            text = "Done"
            setOnClickListener { onDone() }
        }
        btnRow.addView(resetBtn)
        btnRow.addView(doneBtn)
        addView(btnRow)

        updateLabels()
    }

    private fun updateLabels() {
        val h = if (isLandscape) prefs.landscapeHeightDp else prefs.portraitHeightDp
        heightLabel.text = "Height (${if (isLandscape) "Landscape" else "Portrait"}): ${h} dp"
        widthLabel.text = "Width: ${prefs.keyboardWidthPercent}%"
    }
}
