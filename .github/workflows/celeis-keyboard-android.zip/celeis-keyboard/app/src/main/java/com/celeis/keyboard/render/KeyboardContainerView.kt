package com.celeis.keyboard.render

import android.content.Context
import android.content.res.Configuration
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.celeis.keyboard.automation.AutoCounterController
import com.celeis.keyboard.automation.AutoPasteController
import com.celeis.keyboard.automation.StoredPhrasesRepository
import com.celeis.keyboard.clipboard.ClipboardManagerStore
import com.celeis.keyboard.emoji.EmojiHistoryStore
import com.celeis.keyboard.emoji.EmojiPanelView
import com.celeis.keyboard.input.CursorDirection
import com.celeis.keyboard.input.ShiftState
import com.celeis.keyboard.layout.KeyboardPage
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.prefs.OneHandedMode
import com.celeis.keyboard.themes.KeyboardTheme
import com.celeis.keyboard.ui.ActivePanel
import com.celeis.keyboard.ui.AutoCounterPanelView
import com.celeis.keyboard.ui.AutoPastePanelView
import com.celeis.keyboard.ui.ClipboardPanelView
import com.celeis.keyboard.ui.FunctionsPanelView
import com.celeis.keyboard.ui.StoredPhrasesPanelView
import com.celeis.keyboard.ui.ToolbarView

/**
 * Top-level IME view container combining:
 * - Voice listening status banner
 * - Toolbar & suggestion strip
 * - Main content area (KeyboardView / Emoji / Functions / Clipboard / Phrases / AutoCounter / AutoPaste / Resize)
 * - System insets (navigation bar, gesture bar, display cutouts) + configurable bottom offset.
 */
class KeyboardContainerView(
    context: Context,
    private val prefs: CeleisPreferences,
    private val clipboardStore: ClipboardManagerStore,
    private val emojiHistoryStore: EmojiHistoryStore,
    private val phrasesRepo: StoredPhrasesRepository,
    private val counterController: AutoCounterController,
    private val autoPasteController: AutoPasteController,
    private val callbacks: Callbacks
) : LinearLayout(context) {

    interface Callbacks {
        fun onCharacter(text: String)
        fun onShift()
        fun onBackspace()
        fun onEnter()
        fun onSuggestionSelected(word: String)
        fun onInsertPhrase(text: String)
        fun onMoveCursor(direction: CursorDirection)
        fun onToggleUnicodeMode()
        fun onVoiceRequested()
        fun onOpenSettings(section: String? = null)
    }

    val keyboardView = KeyboardView(context)
    private val statusBanner = TextView(context).apply {
        textSize = 12f
        setPadding(20, 8, 20, 8)
        visibility = View.GONE
    }
    private val toolbarView: ToolbarView
    private val contentFrame = FrameLayout(context)

    private var activePanel: ActivePanel = ActivePanel.KEYBOARD
    private var currentTheme: KeyboardTheme? = null

    private var emojiPanel: EmojiPanelView? = null
    private var functionsPanel: FunctionsPanelView? = null
    private var clipboardPanel: ClipboardPanelView? = null
    private var phrasesPanel: StoredPhrasesPanelView? = null
    private var counterPanel: AutoCounterPanelView? = null
    private var autoPastePanel: AutoPastePanelView? = null
    private var resizeOverlay: ResizeOverlayView? = null

    private var systemBottomInsetPx: Int = 0

    init {
        orientation = VERTICAL
        toolbarView = ToolbarView(
            context = context,
            onAction = { action -> handleToolbarAction(action) },
            onSuggestionTap = { word -> callbacks.onSuggestionSelected(word) }
        )

        keyboardView.listener = object : KeyboardView.Listener {
            override fun onKeyCharacter(text: String) = callbacks.onCharacter(text)
            override fun onKeyShift() = callbacks.onShift()
            override fun onKeyBackspace() = callbacks.onBackspace()
            override fun onKeyEnter() = callbacks.onEnter()
            override fun onKeyEmoji() = showPanel(ActivePanel.EMOJI)
            override fun onKeyVoice() = callbacks.onVoiceRequested()
            override fun onKeySymbolsToggle(newPage: KeyboardPage) = Unit
        }

        addView(statusBanner, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(toolbarView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        contentFrame.addView(keyboardView, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(contentFrame, LayoutParams(LayoutParams.MATCH_PARENT, computeBoardHeightPx()))

        ViewCompat.setOnApplyWindowInsetsListener(this) { _, insets ->
            val sysBars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            systemBottomInsetPx = sysBars.bottom
            applyBottomPadding()
            insets
        }
    }

    private fun computeBoardHeightPx(): Int {
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val dp = if (isLandscape) prefs.landscapeHeightDp else prefs.portraitHeightDp
        return (dp * resources.displayMetrics.density).toInt()
    }

    fun applyBottomPadding() {
        val userOffsetPx = (prefs.bottomOffsetDp * resources.displayMetrics.density).toInt()
        setPadding(0, 0, 0, systemBottomInsetPx + userOffsetPx)
    }

    fun refreshConfiguration(theme: KeyboardTheme, shiftState: ShiftState) {
        currentTheme = theme
        setBackgroundColor(theme.backgroundColor)
        applyBottomPadding()

        val lp = contentFrame.layoutParams
        lp.height = computeBoardHeightPx()
        contentFrame.layoutParams = lp

        toolbarView.applyTheme(theme, prefs.typingMode)
        keyboardView.bind(prefs, theme)
        keyboardView.setShiftState(shiftState)

        emojiPanel?.applyTheme(theme)
        functionsPanel?.applyTheme(theme)
        clipboardPanel?.applyTheme(theme)
        phrasesPanel?.applyTheme(theme)
        counterPanel?.applyTheme(theme)
        autoPastePanel?.applyTheme(theme)
    }

    fun updateSuggestions(suggestions: List<String>) {
        val theme = currentTheme ?: return
        toolbarView.updateSuggestions(suggestions, theme)
    }

    fun setStatusMessage(message: String?) {
        if (message.isNullOrBlank()) {
            statusBanner.visibility = View.GONE
        } else {
            statusBanner.visibility = View.VISIBLE
            statusBanner.text = message
            statusBanner.setTextColor(currentTheme?.accentColor ?: 0xFF5B9BFF.toInt())
        }
    }

    fun showPanel(panel: ActivePanel) {
        activePanel = panel
        contentFrame.removeAllViews()
        val match = FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        when (panel) {
            ActivePanel.KEYBOARD -> {
                keyboardView.rebuildLayout()
                contentFrame.addView(keyboardView, match)
            }
            ActivePanel.EMOJI -> {
                val p = emojiPanel ?: EmojiPanelView(
                    context = context,
                    historyStore = emojiHistoryStore,
                    onEmojiSelected = { emoji -> callbacks.onInsertPhrase(emoji) },
                    onBackspace = { callbacks.onBackspace() },
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { emojiPanel = it }
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.FUNCTIONS -> {
                val p = FunctionsPanelView(
                    context = context,
                    prefs = prefs,
                    onMoveCursor = { dir -> callbacks.onMoveCursor(dir) },
                    onOpenPanel = { next -> showPanel(next) },
                    onToggleUnicodeMode = { callbacks.onToggleUnicodeMode() },
                    onOpenThemesSettings = { callbacks.onOpenSettings("themes") },
                    onOpenSettings = { callbacks.onOpenSettings(null) },
                    onToggleOneHanded = {
                        prefs.oneHandedMode = when (prefs.oneHandedMode) {
                            OneHandedMode.OFF -> OneHandedMode.RIGHT
                            OneHandedMode.RIGHT -> OneHandedMode.LEFT
                            OneHandedMode.LEFT -> OneHandedMode.OFF
                        }
                        keyboardView.rebuildLayout()
                        showPanel(ActivePanel.KEYBOARD)
                    },
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { functionsPanel = it }
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.CLIPBOARD -> {
                val p = clipboardPanel ?: ClipboardPanelView(
                    context = context,
                    store = clipboardStore,
                    onInsertText = { text -> callbacks.onInsertPhrase(text) },
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { clipboardPanel = it }
                p.refresh()
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.PHRASES -> {
                val p = phrasesPanel ?: StoredPhrasesPanelView(
                    context = context,
                    repo = phrasesRepo,
                    onInsertPhrase = { text -> callbacks.onInsertPhrase(text) },
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { phrasesPanel = it }
                p.refresh()
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.AUTO_COUNTER -> {
                val p = counterPanel ?: AutoCounterPanelView(
                    context = context,
                    prefs = prefs,
                    controller = counterController,
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { counterPanel = it }
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.AUTOPASTE -> {
                val p = autoPastePanel ?: AutoPastePanelView(
                    context = context,
                    prefs = prefs,
                    controller = autoPasteController,
                    onBackToAbc = { showPanel(ActivePanel.KEYBOARD) }
                ).also { autoPastePanel = it }
                p.refreshFields()
                currentTheme?.let { p.applyTheme(it) }
                contentFrame.addView(p, match)
            }
            ActivePanel.RESIZE -> {
                val p = ResizeOverlayView(
                    context = context,
                    prefs = prefs,
                    onSizeChanged = {
                        currentTheme?.let { refreshConfiguration(it, keyboardView.let { _ -> ShiftState.OFF }) }
                    },
                    onDone = { showPanel(ActivePanel.KEYBOARD) }
                ).also { resizeOverlay = it }
                contentFrame.addView(p, match)
            }
        }
    }

    fun updateCounterStatus(state: com.celeis.keyboard.automation.AutomationState, nextVal: String) {
        counterPanel?.updateStatus(state, nextVal)
    }

    fun updateAutoPasteStatus(state: com.celeis.keyboard.automation.AutomationState) {
        autoPastePanel?.updateStatus(state)
    }

    private fun handleToolbarAction(action: ToolbarView.ToolbarAction) {
        when (action) {
            ToolbarView.ToolbarAction.FUNCTIONS, ToolbarView.ToolbarAction.ARROWS ->
                showPanel(if (activePanel == ActivePanel.FUNCTIONS) ActivePanel.KEYBOARD else ActivePanel.FUNCTIONS)
            ToolbarView.ToolbarAction.TOGGLE_UNICODE_MODE -> callbacks.onToggleUnicodeMode()
            ToolbarView.ToolbarAction.CLIPBOARD ->
                showPanel(if (activePanel == ActivePanel.CLIPBOARD) ActivePanel.KEYBOARD else ActivePanel.CLIPBOARD)
            ToolbarView.ToolbarAction.THEMES -> callbacks.onOpenSettings("themes")
            ToolbarView.ToolbarAction.EMOJI ->
                showPanel(if (activePanel == ActivePanel.EMOJI) ActivePanel.KEYBOARD else ActivePanel.EMOJI)
            ToolbarView.ToolbarAction.AUTO_COUNTER ->
                showPanel(if (activePanel == ActivePanel.AUTO_COUNTER) ActivePanel.KEYBOARD else ActivePanel.AUTO_COUNTER)
            ToolbarView.ToolbarAction.AUTOPASTE ->
                showPanel(if (activePanel == ActivePanel.AUTOPASTE) ActivePanel.KEYBOARD else ActivePanel.AUTOPASTE)
            ToolbarView.ToolbarAction.STORED_PHRASES ->
                showPanel(if (activePanel == ActivePanel.PHRASES) ActivePanel.KEYBOARD else ActivePanel.PHRASES)
            ToolbarView.ToolbarAction.RESIZE ->
                showPanel(if (activePanel == ActivePanel.RESIZE) ActivePanel.KEYBOARD else ActivePanel.RESIZE)
            ToolbarView.ToolbarAction.VOICE -> callbacks.onVoiceRequested()
            ToolbarView.ToolbarAction.SETTINGS -> callbacks.onOpenSettings(null)
        }
    }
}
