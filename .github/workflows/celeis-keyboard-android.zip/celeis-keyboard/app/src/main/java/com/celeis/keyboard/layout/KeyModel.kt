package com.celeis.keyboard.layout

enum class KeyType {
    CHARACTER,
    SHIFT,
    BACKSPACE,
    ENTER,
    SPACE,
    SYMBOLS,
    EMOJI,
    VOICE,
    COMMA,
    PERIOD,
    SETTINGS,
    FUNCTIONS,
    SPACER
}

data class KeySpec(
    val label: String,
    val output: String = label,
    val type: KeyType = KeyType.CHARACTER,
    val weight: Float = 1f,
    val altChars: List<String> = emptyList(),
    val hint: String? = altChars.firstOrNull()
)

enum class KeyboardPage {
    QWERTY,
    SYMBOLS_1,
    SYMBOLS_2
}
