package com.celeis.keyboard.prefs

import android.content.Context
import android.content.SharedPreferences
import com.celeis.keyboard.unicode.TypingMode

enum class OneHandedMode {
    OFF,
    LEFT,
    RIGHT
}

enum class CounterMode {
    NUMERIC,
    ALPHABETIC
}

/**
 * Central persistent preferences store for Celeis Keyboard.
 * All data is stored strictly on-device in private SharedPreferences.
 */
class CeleisPreferences(context: Context) {

    val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // 1. General & Unicode Mode
    var typingMode: TypingMode
        get() = if (prefs.getString(KEY_TYPING_MODE, TypingMode.NORMAL.name) == TypingMode.UNICODE.name) {
            TypingMode.UNICODE
        } else {
            TypingMode.NORMAL
        }
        set(value) = prefs.edit().putString(KEY_TYPING_MODE, value.name).apply()

    var sentenceCapitalization: Boolean
        get() = prefs.getBoolean(KEY_SENTENCE_CAP, true)
        set(value) = prefs.edit().putBoolean(KEY_SENTENCE_CAP, value).apply()

    var persistentCapsLock: Boolean
        get() = prefs.getBoolean(KEY_PERSISTENT_CAPS_LOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_PERSISTENT_CAPS_LOCK, value).apply()

    // 2. Keyboard Layout
    var showNumberRow: Boolean
        get() = prefs.getBoolean(KEY_NUMBER_ROW, true)
        set(value) = prefs.edit().putBoolean(KEY_NUMBER_ROW, value).apply()

    var showNumberRowInSymbols: Boolean
        get() = prefs.getBoolean(KEY_SYMBOLS_NUMBER_ROW, true)
        set(value) = prefs.edit().putBoolean(KEY_SYMBOLS_NUMBER_ROW, value).apply()

    var showAltCharacters: Boolean
        get() = prefs.getBoolean(KEY_ALT_CHARS, true)
        set(value) = prefs.edit().putBoolean(KEY_ALT_CHARS, value).apply()

    var landscapeFullscreen: Boolean
        get() = prefs.getBoolean(KEY_LANDSCAPE_FULLSCREEN, false)
        set(value) = prefs.edit().putBoolean(KEY_LANDSCAPE_FULLSCREEN, value).apply()

    // 3. Keyboard Height & Width (percentages / dp)
    var portraitHeightDp: Int
        get() = prefs.getInt(KEY_PORTRAIT_HEIGHT_DP, DEFAULT_PORTRAIT_HEIGHT_DP)
        set(value) = prefs.edit().putInt(KEY_PORTRAIT_HEIGHT_DP, value.coerceIn(180, 420)).apply()

    var landscapeHeightDp: Int
        get() = prefs.getInt(KEY_LANDSCAPE_HEIGHT_DP, DEFAULT_LANDSCAPE_HEIGHT_DP)
        set(value) = prefs.edit().putInt(KEY_LANDSCAPE_HEIGHT_DP, value.coerceIn(130, 300)).apply()

    var keyboardWidthPercent: Int
        get() = prefs.getInt(KEY_WIDTH_PERCENT, 100)
        set(value) = prefs.edit().putInt(KEY_WIDTH_PERCENT, value.coerceIn(65, 100)).apply()

    var bottomOffsetDp: Int
        get() = prefs.getInt(KEY_BOTTOM_OFFSET_DP, 0)
        set(value) = prefs.edit().putInt(KEY_BOTTOM_OFFSET_DP, value.coerceIn(0, 64)).apply()

    var oneHandedMode: OneHandedMode
        get() = try {
            OneHandedMode.valueOf(prefs.getString(KEY_ONE_HANDED_MODE, OneHandedMode.OFF.name)!!)
        } catch (_: Exception) {
            OneHandedMode.OFF
        }
        set(value) = prefs.edit().putString(KEY_ONE_HANDED_MODE, value.name).apply()

    var oneHandedWidthPercent: Int
        get() = prefs.getInt(KEY_ONE_HANDED_WIDTH_PERCENT, 82)
        set(value) = prefs.edit().putInt(KEY_ONE_HANDED_WIDTH_PERCENT, value.coerceIn(65, 95)).apply()

    // 4. Key Spacing & Appearance
    var horizontalKeySpacingDp: Int
        get() = prefs.getInt(KEY_H_SPACING_DP, 4)
        set(value) = prefs.edit().putInt(KEY_H_SPACING_DP, value.coerceIn(0, 12)).apply()

    var verticalKeySpacingDp: Int
        get() = prefs.getInt(KEY_V_SPACING_DP, 6)
        set(value) = prefs.edit().putInt(KEY_V_SPACING_DP, value.coerceIn(0, 14)).apply()

    var keyCornerRadiusDp: Int
        get() = prefs.getInt(KEY_CORNER_RADIUS_DP, 7)
        set(value) = prefs.edit().putInt(KEY_CORNER_RADIUS_DP, value.coerceIn(0, 20)).apply()

    var keyBorderWidthDp: Int
        get() = prefs.getInt(KEY_BORDER_WIDTH_DP, 0)
        set(value) = prefs.edit().putInt(KEY_BORDER_WIDTH_DP, value.coerceIn(0, 3)).apply()

    var keyFontSizeSp: Int
        get() = prefs.getInt(KEY_FONT_SIZE_SP, 20)
        set(value) = prefs.edit().putInt(KEY_FONT_SIZE_SP, value.coerceIn(14, 28)).apply()

    // 5. Key Press
    /**
     * Keypress repeat / debounce / commit-timing delay in milliseconds (10 ms to 1000 ms).
     * Controls the minimum repeat interval for held Backspace/Arrow keys and optional
     * keypress visual-hold feedback duration without slowing normal single-tap typing.
     */
    var keypressDelayMs: Int
        get() = prefs.getInt(KEY_PRESS_DELAY_MS, 50)
        set(value) = prefs.edit().putInt(KEY_PRESS_DELAY_MS, value.coerceIn(10, 1000)).apply()

    var keyHoldDelayMs: Int
        get() = prefs.getInt(KEY_HOLD_DELAY_MS, 350)
        set(value) = prefs.edit().putInt(KEY_HOLD_DELAY_MS, value.coerceIn(150, 1000)).apply()

    var showKeyPopups: Boolean
        get() = prefs.getBoolean(KEY_SHOW_POPUPS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_POPUPS, value).apply()

    // 6. Sounds & Vibration
    var soundOnKeypress: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var hapticOnKeypress: Boolean
        get() = prefs.getBoolean(KEY_HAPTIC_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTIC_ENABLED, value).apply()

    var hapticIntensity: Int
        get() = prefs.getInt(KEY_HAPTIC_INTENSITY, 50)
        set(value) = prefs.edit().putInt(KEY_HAPTIC_INTENSITY, value.coerceIn(10, 100)).apply()

    // 7. Themes
    var activeThemeId: String
        get() = prefs.getString(KEY_ACTIVE_THEME_ID, DEFAULT_THEME_ID) ?: DEFAULT_THEME_ID
        set(value) = prefs.edit().putString(KEY_ACTIVE_THEME_ID, value).apply()

    // 8. Clipboard
    var clipboardEnabled: Boolean
        get() = prefs.getBoolean(KEY_CLIPBOARD_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CLIPBOARD_ENABLED, value).apply()

    var clipboardMaxItems: Int
        get() = prefs.getInt(KEY_CLIPBOARD_MAX_ITEMS, 30)
        set(value) = prefs.edit().putInt(KEY_CLIPBOARD_MAX_ITEMS, value.coerceIn(10, 100)).apply()

    // 9. Emoji
    var showEmojiKey: Boolean
        get() = prefs.getBoolean(KEY_SHOW_EMOJI_KEY, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_EMOJI_KEY, value).apply()

    // 10. Dictionary & Suggestions
    var showSuggestions: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SUGGESTIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SUGGESTIONS, value).apply()

    var nextWordSuggestions: Boolean
        get() = prefs.getBoolean(KEY_NEXT_WORD_SUGGESTIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_NEXT_WORD_SUGGESTIONS, value).apply()

    // 11. Languages
    var activeLanguageCode: String
        get() = prefs.getString(KEY_LANGUAGE_CODE, "en_US") ?: "en_US"
        set(value) = prefs.edit().putString(KEY_LANGUAGE_CODE, value).apply()

    // 12. Auto Counter
    var counterMode: CounterMode
        get() = try {
            CounterMode.valueOf(prefs.getString(KEY_COUNTER_MODE, CounterMode.NUMERIC.name)!!)
        } catch (_: Exception) {
            CounterMode.NUMERIC
        }
        set(value) = prefs.edit().putString(KEY_COUNTER_MODE, value.name).apply()

    var counterStartValue: String
        get() = prefs.getString(KEY_COUNTER_START, "1") ?: "1"
        set(value) = prefs.edit().putString(KEY_COUNTER_START, value).apply()

    var counterIntervalMs: Int
        get() = prefs.getInt(KEY_COUNTER_INTERVAL_MS, 1000)
        set(value) = prefs.edit().putInt(KEY_COUNTER_INTERVAL_MS, value.coerceIn(200, 10000)).apply()

    // 13. AutoPaste
    var autoPasteIntervalMs: Int
        get() = prefs.getInt(KEY_AUTOPASTE_INTERVAL_MS, 1200)
        set(value) = prefs.edit().putInt(KEY_AUTOPASTE_INTERVAL_MS, value.coerceIn(200, 10000)).apply()

    // 15. Voice Typing
    var showVoiceKey: Boolean
        get() = prefs.getBoolean(KEY_SHOW_VOICE_KEY, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_VOICE_KEY, value).apply()

    fun resetSizeAndSpacingToDefaults() {
        prefs.edit()
            .putInt(KEY_PORTRAIT_HEIGHT_DP, DEFAULT_PORTRAIT_HEIGHT_DP)
            .putInt(KEY_LANDSCAPE_HEIGHT_DP, DEFAULT_LANDSCAPE_HEIGHT_DP)
            .putInt(KEY_WIDTH_PERCENT, 100)
            .putInt(KEY_BOTTOM_OFFSET_DP, 0)
            .putString(KEY_ONE_HANDED_MODE, OneHandedMode.OFF.name)
            .putInt(KEY_ONE_HANDED_WIDTH_PERCENT, 82)
            .putInt(KEY_H_SPACING_DP, 4)
            .putInt(KEY_V_SPACING_DP, 6)
            .putInt(KEY_CORNER_RADIUS_DP, 7)
            .putInt(KEY_BORDER_WIDTH_DP, 0)
            .putInt(KEY_FONT_SIZE_SP, 20)
            .apply()
    }

    fun resetAllToDefaults() {
        prefs.edit().clear().apply()
    }

    companion object {
        const val PREFS_NAME = "celeis_keyboard_prefs"
        const val DEFAULT_THEME_ID = "celeis_default_dark"
        const val DEFAULT_PORTRAIT_HEIGHT_DP = 260
        const val DEFAULT_LANDSCAPE_HEIGHT_DP = 185

        const val KEY_TYPING_MODE = "typing_mode"
        const val KEY_SENTENCE_CAP = "sentence_capitalization"
        const val KEY_PERSISTENT_CAPS_LOCK = "persistent_caps_lock"
        const val KEY_NUMBER_ROW = "show_number_row"
        const val KEY_SYMBOLS_NUMBER_ROW = "show_symbols_number_row"
        const val KEY_ALT_CHARS = "show_alt_chars"
        const val KEY_LANDSCAPE_FULLSCREEN = "landscape_fullscreen"
        const val KEY_PORTRAIT_HEIGHT_DP = "portrait_height_dp"
        const val KEY_LANDSCAPE_HEIGHT_DP = "landscape_height_dp"
        const val KEY_WIDTH_PERCENT = "keyboard_width_percent"
        const val KEY_BOTTOM_OFFSET_DP = "bottom_offset_dp"
        const val KEY_ONE_HANDED_MODE = "one_handed_mode"
        const val KEY_ONE_HANDED_WIDTH_PERCENT = "one_handed_width_percent"
        const val KEY_H_SPACING_DP = "h_key_spacing_dp"
        const val KEY_V_SPACING_DP = "v_key_spacing_dp"
        const val KEY_CORNER_RADIUS_DP = "key_corner_radius_dp"
        const val KEY_BORDER_WIDTH_DP = "key_border_width_dp"
        const val KEY_FONT_SIZE_SP = "key_font_size_sp"
        const val KEY_PRESS_DELAY_MS = "keypress_delay_ms"
        const val KEY_HOLD_DELAY_MS = "key_hold_delay_ms"
        const val KEY_SHOW_POPUPS = "show_key_popups"
        const val KEY_SOUND_ENABLED = "sound_enabled"
        const val KEY_HAPTIC_ENABLED = "haptic_enabled"
        const val KEY_HAPTIC_INTENSITY = "haptic_intensity"
        const val KEY_ACTIVE_THEME_ID = "active_theme_id"
        const val KEY_CLIPBOARD_ENABLED = "clipboard_enabled"
        const val KEY_CLIPBOARD_MAX_ITEMS = "clipboard_max_items"
        const val KEY_SHOW_EMOJI_KEY = "show_emoji_key"
        const val KEY_SHOW_SUGGESTIONS = "show_suggestions"
        const val KEY_NEXT_WORD_SUGGESTIONS = "next_word_suggestions"
        const val KEY_LANGUAGE_CODE = "language_code"
        const val KEY_COUNTER_MODE = "counter_mode"
        const val KEY_COUNTER_START = "counter_start_value"
        const val KEY_COUNTER_INTERVAL_MS = "counter_interval_ms"
        const val KEY_AUTOPASTE_INTERVAL_MS = "autopaste_interval_ms"
        const val KEY_SHOW_VOICE_KEY = "show_voice_key"
    }
}
