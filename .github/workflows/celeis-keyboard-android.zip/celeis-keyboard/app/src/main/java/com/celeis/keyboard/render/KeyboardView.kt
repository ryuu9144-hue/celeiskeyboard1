package com.celeis.keyboard.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import com.celeis.keyboard.input.ShiftState
import com.celeis.keyboard.layout.KeyRect
import com.celeis.keyboard.layout.KeySpec
import com.celeis.keyboard.layout.KeyType
import com.celeis.keyboard.layout.KeyboardLayouts
import com.celeis.keyboard.layout.KeyboardPage
import com.celeis.keyboard.layout.LayoutCalculator
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.themes.BuiltInThemes
import com.celeis.keyboard.themes.KeyboardTheme
import com.celeis.keyboard.unicode.TypingMode
import kotlin.math.roundToInt

/**
 * Lightweight, allocation-free Canvas keyboard renderer.
 * Supports keypress popups, long-press alternate character selection,
 * configurable keypress repeat delay (10-1000 ms), hold delay, custom themes,
 * gallery background images with opacity, and responsive portrait/landscape/one-handed sizing.
 */
class KeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onKeyCharacter(text: String)
        fun onKeyShift()
        fun onKeyBackspace()
        fun onKeyEnter()
        fun onKeyEmoji()
        fun onKeyVoice()
        fun onKeySymbolsToggle(newPage: KeyboardPage)
    }

    var listener: Listener? = null

    private var prefs: CeleisPreferences = CeleisPreferences(context)
    private var theme: KeyboardTheme = BuiltInThemes.CELEIS_DEFAULT_DARK
    private var page: KeyboardPage = KeyboardPage.QWERTY
    private var shiftState: ShiftState = ShiftState.OFF
    private var typingMode: TypingMode = TypingMode.NORMAL

    private var keyRects: List<KeyRect> = emptyList()
    private var activeKeyRect: KeyRect? = null
    private var activePointerId: Int = MotionEvent.INVALID_POINTER_ID
    private var isLongPressTriggered = false

    private var bgBitmap: Bitmap? = null
    private var loadedBgPath: String? = null
    private val bgSrcRect = Rect()
    private val bgDstRect = Rect()

    private val handler = Handler(Looper.getMainLooper())
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val drawRect = RectF()

    private var keyPopupWindow: PopupWindow? = null
    private var keyPopupText: TextView? = null
    private var altPopupWindow: PopupWindow? = null
    private var altCharViews: List<TextView> = emptyList()
    private var selectedAltIndex: Int = 0

    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private val longPressRunnable = Runnable {
        val kr = activeKeyRect ?: return@Runnable
        if (kr.key.altChars.isNotEmpty()) {
            isLongPressTriggered = true
            dismissKeyPopup()
            showAltCharsPopup(kr)
        }
    }

    private val repeatRunnable = object : Runnable {
        override fun run() {
            val kr = activeKeyRect ?: return
            if (kr.key.type == KeyType.BACKSPACE) {
                listener?.onKeyBackspace()
                handler.postDelayed(this, prefs.keypressDelayMs.toLong())
            }
        }
    }

    fun bind(prefs: CeleisPreferences, theme: KeyboardTheme) {
        this.prefs = prefs
        this.theme = theme
        this.typingMode = prefs.typingMode
        loadBackgroundIfNeeded(theme.backgroundImagePath)
        rebuildLayout()
        invalidate()
    }

    fun setShiftState(state: ShiftState) {
        if (shiftState != state) {
            shiftState = state
            invalidate()
        }
    }

    fun setTypingMode(mode: TypingMode) {
        if (typingMode != mode) {
            typingMode = mode
            invalidate()
        }
    }

    fun setPage(newPage: KeyboardPage) {
        if (page != newPage) {
            page = newPage
            rebuildLayout()
            invalidate()
        }
    }

    fun getPage(): KeyboardPage = page

    private fun loadBackgroundIfNeeded(path: String?) {
        if (path == loadedBgPath) return
        loadedBgPath = path
        bgBitmap?.recycle()
        bgBitmap = null
        if (!path.isNullOrEmpty()) {
            try {
                bgBitmap = BitmapFactory.decodeFile(path)
            } catch (_: Exception) {
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildLayout()
    }

    fun rebuildLayout() {
        if (width <= 0 || height <= 0) return
        val density = resources.displayMetrics.density
        val rows = KeyboardLayouts.getRows(
            page = page,
            showNumberRow = prefs.showNumberRow,
            showNumberRowInSymbols = prefs.showNumberRowInSymbols,
            showEmojiKey = prefs.showEmojiKey,
            showVoiceKey = prefs.showVoiceKey,
            showAltChars = prefs.showAltCharacters
        )
        keyRects = LayoutCalculator.computeKeyRects(
            rows = rows,
            availableWidthPx = width.toFloat(),
            keyboardHeightPx = height.toFloat(),
            widthPercent = prefs.keyboardWidthPercent,
            oneHandedMode = prefs.oneHandedMode,
            oneHandedWidthPercent = prefs.oneHandedWidthPercent,
            hSpacingPx = prefs.horizontalKeySpacingDp * density,
            vSpacingPx = prefs.verticalKeySpacingDp * density
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(theme.backgroundColor)

        val bmp = bgBitmap
        if (bmp != null && !bmp.isRecycled) {
            bgPaint.alpha = (theme.backgroundOpacity.coerceIn(0.05f, 1f) * 255).roundToInt()
            bgSrcRect.set(0, 0, bmp.width, bmp.height)
            bgDstRect.set(0, 0, width, height)
            canvas.drawBitmap(bmp, bgSrcRect, bgDstRect, bgPaint)
        }

        val density = resources.displayMetrics.density
        val scaledDensity = resources.displayMetrics.scaledDensity
        val cornerPx = prefs.keyCornerRadiusDp * density
        val borderWidthPx = prefs.keyBorderWidthDp * density
        val baseTextSize = prefs.keyFontSizeSp * scaledDensity

        borderPaint.strokeWidth = borderWidthPx
        borderPaint.color = theme.keyBorderColor

        for (kr in keyRects) {
            val isPressed = kr === activeKeyRect
            val key = kr.key
            drawRect.set(kr.left, kr.top, kr.right, kr.bottom)

            keyPaint.color = when {
                isPressed -> theme.keyPressedColor
                key.type == KeyType.ENTER -> theme.enterKeyBackgroundColor
                key.type == KeyType.SHIFT && shiftState != ShiftState.OFF -> theme.accentColor
                key.type != KeyType.CHARACTER && key.type != KeyType.SPACE -> theme.specialKeyBackgroundColor
                else -> theme.keyBackgroundColor
            }

            val radius = if (key.type == KeyType.ENTER) (drawRect.height() * 0.48f) else cornerPx
            canvas.drawRoundRect(drawRect, radius, radius, keyPaint)

            if (borderWidthPx > 0f && key.type != KeyType.ENTER) {
                canvas.drawRoundRect(drawRect, radius, radius, borderPaint)
            }

            val label = resolveDisplayLabel(key)
            textPaint.color = when (key.type) {
                KeyType.ENTER -> theme.enterKeyTextColor
                KeyType.SHIFT -> if (shiftState != ShiftState.OFF) theme.enterKeyTextColor else theme.keyTextColor
                else -> theme.keyTextColor
            }
            textPaint.textSize = when (key.type) {
                KeyType.SPACE -> baseTextSize * 0.65f
                KeyType.SYMBOLS -> baseTextSize * 0.72f
                else -> baseTextSize
            }

            val textY = kr.centerY() - (textPaint.descent() + textPaint.ascent()) * 0.5f
            canvas.drawText(label, kr.centerX(), textY, textPaint)

            if (!key.hint.isNullOrEmpty() && key.type == KeyType.CHARACTER) {
                hintPaint.color = theme.keyHintTextColor
                hintPaint.textSize = baseTextSize * 0.48f
                canvas.drawText(key.hint, kr.right - 5f * density, kr.top + 11f * density, hintPaint)
            }
        }
    }

    private fun resolveDisplayLabel(key: KeySpec): String {
        if (key.type == KeyType.SPACE) {
            return if (typingMode == TypingMode.UNICODE) "English • U+2060" else "English"
        }
        if (key.type == KeyType.SHIFT && page == KeyboardPage.QWERTY) {
            return when (shiftState) {
                ShiftState.OFF -> "⇧"
                ShiftState.SHIFTED -> "⬆"
                ShiftState.CAPS_LOCK -> "⇪"
            }
        }
        if (key.type == KeyType.CHARACTER && page == KeyboardPage.QWERTY &&
            key.label.length == 1 && key.label[0].isLetter()
        ) {
            return if (shiftState != ShiftState.OFF) key.label.uppercase() else key.label.lowercase()
        }
        return key.label
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val idx = event.actionIndex
                activePointerId = event.getPointerId(idx)
                val x = event.getX(idx)
                val y = event.getY(idx)
                val hit = findKeyAt(x, y)
                activeKeyRect = hit
                isLongPressTriggered = false
                if (hit != null) {
                    performFeedback()
                    if (hit.key.type == KeyType.BACKSPACE) {
                        listener?.onKeyBackspace()
                        handler.postDelayed(repeatRunnable, prefs.keyHoldDelayMs.toLong())
                    } else {
                        if (prefs.showKeyPopups && hit.key.type == KeyType.CHARACTER) {
                            showKeyPopup(hit)
                        }
                        if (hit.key.altChars.isNotEmpty()) {
                            handler.postDelayed(longPressRunnable, prefs.keyHoldDelayMs.toLong())
                        }
                    }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isLongPressTriggered && altCharViews.isNotEmpty()) {
                    val idx = event.findPointerIndex(activePointerId)
                    if (idx >= 0) {
                        updateAltSelection(event.rawX)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                handler.removeCallbacks(repeatRunnable)
                dismissKeyPopup()

                val releasedKey = activeKeyRect
                if (isLongPressTriggered && altCharViews.isNotEmpty()) {
                    val chosen = altCharViews.getOrNull(selectedAltIndex)?.text?.toString()
                    dismissAltPopup()
                    if (event.actionMasked == MotionEvent.ACTION_UP && !chosen.isNullOrEmpty()) {
                        listener?.onKeyCharacter(chosen)
                    }
                } else {
                    dismissAltPopup()
                    if (event.actionMasked == MotionEvent.ACTION_UP && releasedKey != null) {
                        dispatchKeyTap(releasedKey.key)
                    }
                }
                activeKeyRect = null
                activePointerId = MotionEvent.INVALID_POINTER_ID
                isLongPressTriggered = false
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun dispatchKeyTap(key: KeySpec) {
        when (key.type) {
            KeyType.CHARACTER, KeyType.COMMA, KeyType.PERIOD, KeyType.SPACE -> {
                listener?.onKeyCharacter(key.output)
            }
            KeyType.SHIFT -> {
                when (page) {
                    KeyboardPage.QWERTY -> listener?.onKeyShift()
                    KeyboardPage.SYMBOLS_1 -> {
                        page = KeyboardPage.SYMBOLS_2
                        rebuildLayout()
                        listener?.onKeySymbolsToggle(KeyboardPage.SYMBOLS_2)
                    }
                    KeyboardPage.SYMBOLS_2 -> {
                        page = KeyboardPage.SYMBOLS_1
                        rebuildLayout()
                        listener?.onKeySymbolsToggle(KeyboardPage.SYMBOLS_1)
                    }
                }
            }
            KeyType.BACKSPACE -> {
                // Handled on ACTION_DOWN + repeatRunnable
            }
            KeyType.ENTER -> listener?.onKeyEnter()
            KeyType.EMOJI -> listener?.onKeyEmoji()
            KeyType.VOICE -> listener?.onKeyVoice()
            KeyType.SYMBOLS -> {
                val next = if (page == KeyboardPage.QWERTY) KeyboardPage.SYMBOLS_1 else KeyboardPage.QWERTY
                page = next
                rebuildLayout()
                listener?.onKeySymbolsToggle(next)
            }
            else -> Unit
        }
    }

    private fun findKeyAt(x: Float, y: Float): KeyRect? {
        for (kr in keyRects) {
            if (kr.contains(x, y)) return kr
        }
        return null
    }

    private fun performFeedback() {
        if (prefs.soundOnKeypress) {
            audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.5f)
        }
        if (prefs.hapticOnKeypress) {
            val vib = vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val amp = (prefs.hapticIntensity * 2.55f).roundToInt().coerceIn(1, 255)
                vib.vibrate(VibrationEffect.createOneShot(18L, amp))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(18L)
            }
        }
    }

    private fun showKeyPopup(kr: KeyRect) {
        val label = resolveDisplayLabel(kr.key)
        if (keyPopupWindow == null) {
            val tv = TextView(context).apply {
                gravity = Gravity.CENTER
                textSize = 24f
                setPadding(24, 14, 24, 14)
            }
            keyPopupText = tv
            keyPopupWindow = PopupWindow(
                tv,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                false
            ).apply {
                isTouchable = false
                isClippingEnabled = false
            }
        }
        keyPopupText?.apply {
            text = label
            setTextColor(theme.popupTextColor)
            setBackgroundColor(theme.popupBackgroundColor)
        }
        val loc = IntArray(2)
        getLocationInWindow(loc)
        val popupX = (loc[0] + kr.centerX() - 36).roundToInt()
        val popupY = (loc[1] + kr.top - 96).roundToInt()
        keyPopupWindow?.showAtLocation(this, Gravity.NO_GRAVITY, popupX, popupY)
    }

    private fun dismissKeyPopup() {
        try {
            keyPopupWindow?.dismiss()
        } catch (_: Exception) {
        }
    }

    private fun showAltCharsPopup(kr: KeyRect) {
        dismissAltPopup()
        val density = resources.displayMetrics.density
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(theme.popupBackgroundColor)
            setPadding((6 * density).roundToInt(), (6 * density).roundToInt(), (6 * density).roundToInt(), (6 * density).roundToInt())
        }
        val views = mutableListOf<TextView>()
        kr.key.altChars.forEachIndexed { index, ch ->
            val tv = TextView(context).apply {
                text = ch
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding((10 * density).roundToInt(), (6 * density).roundToInt(), (10 * density).roundToInt(), (6 * density).roundToInt())
                setTextColor(theme.popupTextColor)
                if (index == 0) setBackgroundColor(theme.accentColor)
            }
            views.add(tv)
            container.addView(tv)
        }
        altCharViews = views
        selectedAltIndex = 0

        val pw = PopupWindow(
            container,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            false
        ).apply {
            isTouchable = false
            isClippingEnabled = false
        }
        altPopupWindow = pw
        val loc = IntArray(2)
        getLocationInWindow(loc)
        val popupX = (loc[0] + kr.left).roundToInt().coerceAtLeast(8)
        val popupY = (loc[1] + kr.top - (56 * density)).roundToInt()
        pw.showAtLocation(this, Gravity.NO_GRAVITY, popupX, popupY)
    }

    private fun updateAltSelection(rawX: Float) {
        if (altCharViews.isEmpty()) return
        val loc = IntArray(2)
        altCharViews.forEachIndexed { idx, tv ->
            tv.getLocationOnScreen(loc)
            val left = loc[0]
            val right = left + tv.width
            if (rawX >= left && rawX <= right) {
                selectedAltIndex = idx
            }
        }
        altCharViews.forEachIndexed { idx, tv ->
            tv.setBackgroundColor(if (idx == selectedAltIndex) theme.accentColor else 0x00000000)
        }
    }

    private fun dismissAltPopup() {
        try {
            altPopupWindow?.dismiss()
        } catch (_: Exception) {
        }
        altPopupWindow = null
        altCharViews = emptyList()
    }
}
