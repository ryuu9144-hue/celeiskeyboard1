package com.celeis.keyboard.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat

/**
 * Voice-to-text controller using Android's SpeechRecognizer API.
 * - Verifies RECORD_AUDIO runtime permission and SpeechRecognizer availability.
 * - Never records in the background; only listens on explicit microphone tap.
 */
class VoiceInputController(
    private val context: Context,
    private val onListeningStateChanged: (Boolean, String?) -> Unit,
    private val onRecognizedText: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    var isListening: Boolean = false
        private set

    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isServiceAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun toggleListening(languageTag: String) {
        if (isListening) {
            stopListening()
        } else {
            startListening(languageTag)
        }
    }

    fun startListening(languageTag: String) {
        if (!hasAudioPermission()) {
            onListeningStateChanged(false, "Microphone permission required. Grant it in Celeis Settings > Voice Typing.")
            return
        }
        if (!isServiceAvailable()) {
            onListeningStateChanged(false, "Speech recognition service is unavailable on this device.")
            return
        }

        stopListening()
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    onListeningStateChanged(true, "Listening…")
                }

                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    isListening = false
                    onListeningStateChanged(false, null)
                }

                override fun onError(error: Int) {
                    isListening = false
                    val message = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied."
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Speech service requires network or an installed offline language pack."
                        else -> "Voice input error ($error)."
                    }
                    onListeningStateChanged(false, message)
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull()?.trim()
                    if (!best.isNullOrEmpty()) {
                        onRecognizedText("$best ")
                    }
                    onListeningStateChanged(false, null)
                }

                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag.replace('_', '-'))
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer = recognizer
            isListening = true
            onListeningStateChanged(true, "Listening…")
            recognizer.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            onListeningStateChanged(false, "Unable to start voice typing: ${e.message}")
        }
    }

    fun stopListening() {
        isListening = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        onListeningStateChanged(false, null)
    }
}
