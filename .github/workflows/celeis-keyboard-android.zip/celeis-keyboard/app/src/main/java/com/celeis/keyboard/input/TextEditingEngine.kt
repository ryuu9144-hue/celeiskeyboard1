package com.celeis.keyboard.input

import android.os.SystemClock
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.unicode.TypingMode
import com.celeis.keyboard.unicode.UnicodeProcessor

enum class ShiftState {
    OFF,
    SHIFTED,
    CAPS_LOCK
}

enum class CursorDirection {
    LEFT,
    RIGHT,
    UP,
    DOWN
}

/**
 * Handles text insertion, Smart Backspace, Shift/CapsLock state machine,
 * sentence capitalization, selection replacement, and arrow-key cursor navigation.
 */
class TextEditingEngine(private val prefs: CeleisPreferences) {

    var shiftState: ShiftState = if (prefs.persistentCapsLock) ShiftState.CAPS_LOCK else ShiftState.OFF
        private set

    private var lastShiftTapTimeMs: Long = 0L

    fun syncFromPreferences() {
        shiftState = if (prefs.persistentCapsLock) {
            ShiftState.CAPS_LOCK
        } else if (shiftState == ShiftState.CAPS_LOCK) {
            ShiftState.OFF
        } else {
            shiftState
        }
    }

    /**
     * Handles single tap and double tap on the Shift key.
     * Double tap within 350 ms engages persistent Caps Lock.
     */
    fun onShiftTap(nowMs: Long = SystemClock.uptimeMillis()): ShiftState {
        val isDoubleTap = (nowMs - lastShiftTapTimeMs) <= DOUBLE_TAP_WINDOW_MS
        lastShiftTapTimeMs = nowMs

        shiftState = when {
            shiftState == ShiftState.CAPS_LOCK -> {
                prefs.persistentCapsLock = false
                ShiftState.OFF
            }
            isDoubleTap -> {
                prefs.persistentCapsLock = true
                ShiftState.CAPS_LOCK
            }
            shiftState == ShiftState.SHIFTED -> {
                ShiftState.OFF
            }
            else -> {
                ShiftState.SHIFTED
            }
        }
        return shiftState
    }

    fun isUppercaseActive(): Boolean = shiftState != ShiftState.OFF

    /**
     * Updates auto-capitalization at sentence boundaries when Caps Lock is not active.
     */
    fun updateAutoCapitalization(ic: InputConnection?, editorInfo: EditorInfo?) {
        if (prefs.persistentCapsLock || shiftState == ShiftState.CAPS_LOCK) {
            shiftState = ShiftState.CAPS_LOCK
            return
        }
        if (!prefs.sentenceCapitalization || ic == null || editorInfo == null) {
            if (shiftState == ShiftState.SHIFTED) shiftState = ShiftState.OFF
            return
        }

        val capsMode = ic.getCursorCapsMode(editorInfo.inputType)
        shiftState = if (capsMode != 0) ShiftState.SHIFTED else ShiftState.OFF
    }

    /**
     * Commits a typed character or string, applying Shift/CapsLock and Unicode Mode.
     */
    fun commitText(ic: InputConnection?, rawText: String, editorInfo: EditorInfo?) {
        if (ic == null || rawText.isEmpty()) return

        val transformed = if (rawText.length == 1 && rawText[0].isLetter() && isUppercaseActive()) {
            rawText.uppercase()
        } else {
            rawText
        }

        val textAfterCursor = ic.getTextAfterCursor(2, 0)
        val finalToCommit = UnicodeProcessor.processInput(
            input = transformed,
            mode = prefs.typingMode,
            textAfterCursor = textAfterCursor
        )

        ic.beginBatchEdit()
        ic.commitText(finalToCommit, 1)
        ic.endBatchEdit()

        // Reset single-tap shift after typing a letter; keep Caps Lock active
        if (shiftState == ShiftState.SHIFTED && rawText.any { it.isLetter() }) {
            shiftState = ShiftState.OFF
        }

        // Re-evaluate sentence capitalization after space or punctuation
        if (rawText == " " || rawText == "." || rawText == "!" || rawText == "?" || rawText == "\n") {
            updateAutoCapitalization(ic, editorInfo)
        }
    }

    /**
     * Commits a multi-character phrase, clipboard item, or suggestion.
     * In Unicode mode, ensures English letters get U+2060 without duplicating existing joiners.
     */
    fun commitPhrase(ic: InputConnection?, phrase: String) {
        if (ic == null || phrase.isEmpty()) return
        val textAfterCursor = ic.getTextAfterCursor(2, 0)
        val processed = UnicodeProcessor.processInput(
            input = phrase,
            mode = prefs.typingMode,
            textAfterCursor = textAfterCursor
        )
        ic.beginBatchEdit()
        ic.commitText(processed, 1)
        ic.endBatchEdit()
    }

    /**
     * Commits a suggestion word by replacing the current partial word before the cursor.
     */
    fun commitSuggestion(ic: InputConnection?, suggestion: String) {
        if (ic == null || suggestion.isEmpty()) return
        val before = ic.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        var deleteCount = 0
        for (i in before.indices.reversed()) {
            val ch = before[i]
            if (ch.isWhitespace() || (!ch.isLetterOrDigit() && ch != UnicodeProcessor.WORD_JOINER && ch != '\'')) {
                break
            }
            deleteCount++
        }
        ic.beginBatchEdit()
        if (deleteCount > 0) {
            ic.deleteSurroundingText(deleteCount, 0)
        }
        val toCommit = UnicodeProcessor.processInput("$suggestion ", prefs.typingMode, null)
        ic.commitText(toCommit, 1)
        ic.endBatchEdit()
    }

    /**
     * Performs Smart Backspace:
     * - If there is an active selection, deletes the selection.
     * - Otherwise deletes `[A-Za-z]\u2060` as a unit or one grapheme cluster.
     */
    fun performSmartBackspace(ic: InputConnection?, editorInfo: EditorInfo?) {
        if (ic == null) return

        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
            updateAutoCapitalization(ic, editorInfo)
            return
        }

        val before = ic.getTextBeforeCursor(16, 0)
        val deleteLen = UnicodeProcessor.computeSmartBackspaceLength(before)
        if (deleteLen > 0) {
            ic.deleteSurroundingText(deleteLen, 0)
        } else {
            // Fallback for editors that don't expose surrounding text
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
        }
        updateAutoCapitalization(ic, editorInfo)
    }

    /**
     * Moves the cursor using Android DPAD key events (never inserts arrow symbols).
     */
    fun moveCursor(ic: InputConnection?, direction: CursorDirection) {
        if (ic == null) return
        val keyCode = when (direction) {
            CursorDirection.LEFT -> KeyEvent.KEYCODE_DPAD_LEFT
            CursorDirection.RIGHT -> KeyEvent.KEYCODE_DPAD_RIGHT
            CursorDirection.UP -> KeyEvent.KEYCODE_DPAD_UP
            CursorDirection.DOWN -> KeyEvent.KEYCODE_DPAD_DOWN
        }
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    /**
     * Extracts the current word prefix before the cursor with U+2060 stripped
     * so dictionary suggestions work identically in Normal and Unicode modes.
     */
    fun getCurrentWordPrefix(ic: InputConnection?): Pair<String, String?> {
        if (ic == null) return "" to null
        val beforeRaw = ic.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val clean = UnicodeProcessor.stripWordJoiners(beforeRaw)
        if (clean.isEmpty()) return "" to null

        val lastSpaceIdx = clean.indexOfLast { it.isWhitespace() }
        val currentToken = if (lastSpaceIdx >= 0) clean.substring(lastSpaceIdx + 1) else clean
        val previousToken = if (lastSpaceIdx > 0) {
            clean.substring(0, lastSpaceIdx).trimEnd().substringAfterLast(' ').ifEmpty { null }
        } else {
            null
        }
        return currentToken to previousToken
    }

    companion object {
        private const val DOUBLE_TAP_WINDOW_MS = 350L
    }
}
