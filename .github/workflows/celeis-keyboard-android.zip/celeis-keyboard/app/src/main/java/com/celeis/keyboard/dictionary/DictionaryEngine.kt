package com.celeis.keyboard.dictionary

import android.content.Context
import org.json.JSONArray

/**
 * Local English dictionary and manual-selection suggestion engine.
 *
 * Design guarantees:
 * - NO autocorrect.
 * - NO automatic word replacement.
 * - NO glide/swipe typing.
 * Suggestions are only inserted when the user explicitly taps a suggestion chip.
 */
class DictionaryEngine(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val baseWords: List<String> = listOf(
        "the", "be", "to", "of", "and", "in", "that", "have", "it", "for",
        "not", "on", "with", "as", "you", "do", "at", "this", "but", "by",
        "from", "they", "we", "say", "or", "an", "will", "my", "one", "all",
        "would", "there", "their", "what", "so", "up", "out", "if", "about", "who",
        "get", "which", "go", "me", "when", "make", "can", "like", "time", "no",
        "just", "know", "take", "people", "into", "year", "your", "good", "some", "could",
        "them", "see", "other", "than", "then", "now", "look", "only", "come", "its",
        "over", "think", "also", "back", "after", "use", "two", "how", "our", "work",
        "first", "well", "way", "even", "new", "want", "because", "any", "these", "give",
        "day", "most", "hello", "thanks", "thank", "please", "sorry", "great", "today", "tomorrow",
        "tonight", "morning", "evening", "night", "keyboard", "celeis", "unicode", "android", "message", "email",
        "phone", "meeting", "schedule", "project", "update", "confirm", "ready", "waiting", "working", "sending",
        "check", "settings", "theme", "clipboard", "phrase", "custom", "layout", "number", "symbol", "emoji"
    )

    private val bigrams: Map<String, List<String>> = mapOf(
        "thank" to listOf("you", "you!"),
        "thanks" to listOf("for", "again"),
        "good" to listOf("morning", "night", "evening"),
        "how" to listOf("are", "is", "about"),
        "are" to listOf("you", "we", "they"),
        "on" to listOf("my", "the", "time"),
        "see" to listOf("you", "the"),
        "please" to listOf("let", "check", "send"),
        "let" to listOf("me", "us", "know"),
        "celeis" to listOf("keyboard", "unicode", "theme")
    )

    fun getPersonalWords(): List<String> {
        val raw = prefs.getString(KEY_PERSONAL_WORDS, "[]") ?: "[]"
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun addPersonalWord(word: String) {
        val w = word.trim()
        if (w.isEmpty()) return
        val list = getPersonalWords().toMutableList()
        if (list.none { it.equals(w, ignoreCase = true) }) {
            list.add(w)
            savePersonalWords(list)
        }
    }

    fun removePersonalWord(word: String) {
        savePersonalWords(getPersonalWords().filterNot { it.equals(word, ignoreCase = true) })
    }

    fun clearPersonalWords() {
        savePersonalWords(emptyList())
    }

    fun getSuggestions(
        currentPrefix: String,
        previousWord: String?,
        includeNextWord: Boolean
    ): List<String> {
        val prefix = currentPrefix.trim().lowercase()
        if (prefix.isEmpty()) {
            if (!includeNextWord || previousWord.isNullOrBlank()) return emptyList()
            return bigrams[previousWord.trim().lowercase()].orEmpty().take(3)
        }

        val personal = getPersonalWords()
            .filter { it.lowercase().startsWith(prefix) }
            .take(3)

        val baseMatches = baseWords
            .filter { it.startsWith(prefix) && personal.none { p -> p.equals(it, ignoreCase = true) } }
            .take(3 - personal.size)

        val combined = (personal + baseMatches).take(3)
        if (currentPrefix.firstOrNull()?.isUpperCase() == true) {
            return combined.map { word ->
                word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            }
        }
        return combined
    }

    private fun savePersonalWords(words: List<String>) {
        prefs.edit().putString(KEY_PERSONAL_WORDS, JSONArray(words).toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "celeis_dictionary"
        private const val KEY_PERSONAL_WORDS = "personal_words"
    }
}
