package com.celeis.keyboard.automation

import android.os.Handler
import android.os.Looper
import com.celeis.keyboard.prefs.CounterMode

/**
 * Pure counter formatting and stepping logic for Numeric (1, 2, 3...)
 * and Alphabetic (A, B, ..., Z, AA, AB, ...) counting.
 */
object CounterFormatter {

    fun toAlphabetic(indexOneBased: Long): String {
        if (indexOneBased <= 0) return "A"
        var n = indexOneBased
        val sb = StringBuilder()
        while (n > 0) {
            n--
            val rem = (n % 26).toInt()
            sb.append(('A'.code + rem).toChar())
            n /= 26
        }
        return sb.reverse().toString()
    }

    fun parseAlphabeticStart(input: String): Long {
        val clean = input.trim().uppercase()
        if (clean.isEmpty() || !clean.all { it in 'A'..'Z' }) return 1L
        var value = 0L
        for (ch in clean) {
            value = value * 26L + (ch - 'A' + 1)
        }
        return value.coerceAtLeast(1L)
    }

    fun formatValue(mode: CounterMode, index: Long): String {
        return when (mode) {
            CounterMode.NUMERIC -> index.toString()
            CounterMode.ALPHABETIC -> toAlphabetic(index)
        }
    }
}

enum class AutomationState {
    STOPPED,
    RUNNING,
    PAUSED
}

/**
 * Auto Counter controller: inserts sequential numeric or alphabetic values
 * into the currently focused text field at a configurable interval.
 * Stops automatically when focus is lost or a sensitive field is active.
 */
class AutoCounterController(
    private val onInsertValue: (String) -> Unit,
    private val onStateChanged: (AutomationState, String) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    var state: AutomationState = AutomationState.STOPPED
        private set

    var mode: CounterMode = CounterMode.NUMERIC
    var intervalMs: Long = 1000L
    private var startIndex: Long = 1L
    private var currentIndex: Long = 1L

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (state != AutomationState.RUNNING) return
            val value = CounterFormatter.formatValue(mode, currentIndex)
            onInsertValue(value)
            currentIndex++
            onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
            handler.postDelayed(this, intervalMs.coerceIn(200L, 10000L))
        }
    }

    fun configure(mode: CounterMode, startRaw: String, intervalMs: Long) {
        this.mode = mode
        this.intervalMs = intervalMs.coerceIn(200L, 10000L)
        this.startIndex = when (mode) {
            CounterMode.NUMERIC -> startRaw.trim().toLongOrNull() ?: 1L
            CounterMode.ALPHABETIC -> CounterFormatter.parseAlphabeticStart(startRaw)
        }
        if (state == AutomationState.STOPPED) {
            currentIndex = startIndex
            onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
        }
    }

    fun start() {
        handler.removeCallbacks(tickRunnable)
        currentIndex = startIndex
        state = AutomationState.RUNNING
        onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
        handler.post(tickRunnable)
    }

    fun pause() {
        if (state != AutomationState.RUNNING) return
        handler.removeCallbacks(tickRunnable)
        state = AutomationState.PAUSED
        onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
    }

    fun resume() {
        if (state != AutomationState.PAUSED) return
        state = AutomationState.RUNNING
        onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
        handler.post(tickRunnable)
    }

    fun stop() {
        handler.removeCallbacks(tickRunnable)
        state = AutomationState.STOPPED
        onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
    }

    fun reset() {
        stop()
        currentIndex = startIndex
        onStateChanged(state, CounterFormatter.formatValue(mode, currentIndex))
    }

    fun previewNext(): String = CounterFormatter.formatValue(mode, currentIndex)
}
