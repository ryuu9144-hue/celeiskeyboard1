package com.celeis.keyboard.emoji

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class EmojiEntry(
    val emoji: String,
    val keywords: String
)

enum class EmojiCategory(val label: String, val icon: String) {
    RECENT("Recent", "🕒"),
    SMILEYS("Smileys", "😀"),
    GESTURES("Gestures", "👍"),
    HEARTS("Hearts", "❤️"),
    ANIMALS("Animals", "🐾"),
    FOOD("Food", "🍕"),
    TRAVEL("Travel", "✈️"),
    OBJECTS("Objects", "💡"),
    SYMBOLS("Symbols", "✨")
}

object EmojiRepository {

    val catalog: Map<EmojiCategory, List<EmojiEntry>> = mapOf(
        EmojiCategory.SMILEYS to listOf(
            EmojiEntry("😀", "grinning happy smile"),
            EmojiEntry("😃", "smiley happy"),
            EmojiEntry("😄", "smile laugh"),
            EmojiEntry("😁", "grin beam"),
            EmojiEntry("😆", "laugh xd"),
            EmojiEntry("😅", "sweat nervous laugh"),
            EmojiEntry("🤣", "rofl laugh"),
            EmojiEntry("😂", "joy tears laugh"),
            EmojiEntry("🙂", "slightly smiling"),
            EmojiEntry("🙃", "upside down"),
            EmojiEntry("😉", "wink"),
            EmojiEntry("😊", "blush happy"),
            EmojiEntry("😇", "angel halo"),
            EmojiEntry("🥰", "love hearts"),
            EmojiEntry("😍", "heart eyes love"),
            EmojiEntry("🤩", "star struck"),
            EmojiEntry("😘", "kiss"),
            EmojiEntry("😋", "yum tongue"),
            EmojiEntry("😎", "cool sunglasses"),
            EmojiEntry("🤓", "nerd glasses"),
            EmojiEntry("🧐", "monocle"),
            EmojiEntry("🤔", "thinking"),
            EmojiEntry("🤫", "shush quiet"),
            EmojiEntry("🫡", "salute"),
            EmojiEntry("🫠", "melting"),
            EmojiEntry("😴", "sleep"),
            EmojiEntry("🥳", "party celebrate"),
            EmojiEntry("🥺", "pleading puppy eyes"),
            EmojiEntry("😭", "cry sob"),
            EmojiEntry("😤", "triumph steam"),
            EmojiEntry("😡", "angry mad"),
            EmojiEntry("🤯", "mind blown"),
            EmojiEntry("😱", "scream shock"),
            EmojiEntry("🥶", "cold freezing"),
            EmojiEntry("🥵", "hot")
        ),
        EmojiCategory.GESTURES to listOf(
            EmojiEntry("👍", "thumbs up like yes"),
            EmojiEntry("👍🏽", "thumbs up medium"),
            EmojiEntry("👎", "thumbs down no"),
            EmojiEntry("👌", "ok perfect"),
            EmojiEntry("✌️", "peace victory"),
            EmojiEntry("🤞", "crossed fingers luck"),
            EmojiEntry("🫶", "heart hands"),
            EmojiEntry("👏", "clap applause"),
            EmojiEntry("🙌", "raise hands celebrate"),
            EmojiEntry("🤝", "handshake deal"),
            EmojiEntry("🙏", "pray please thank you"),
            EmojiEntry("💪", "muscle strong"),
            EmojiEntry("👋", "wave hello bye"),
            EmojiEntry("✍️", "writing"),
            EmojiEntry("👩‍💻", "woman technologist developer"),
            EmojiEntry("👨‍💻", "man technologist developer"),
            EmojiEntry("👨‍👩‍👧‍👦", "family")
        ),
        EmojiCategory.HEARTS to listOf(
            EmojiEntry("❤️", "red heart love"),
            EmojiEntry("🧡", "orange heart"),
            EmojiEntry("💛", "yellow heart"),
            EmojiEntry("💚", "green heart"),
            EmojiEntry("💙", "blue heart"),
            EmojiEntry("💜", "purple heart"),
            EmojiEntry("🖤", "black heart"),
            EmojiEntry("🤍", "white heart"),
            EmojiEntry("🩵", "light blue heart"),
            EmojiEntry("❤️‍🔥", "heart on fire"),
            EmojiEntry("💖", "sparkling heart"),
            EmojiEntry("💯", "100 percent"),
            EmojiEntry("💥", "boom collision")
        ),
        EmojiCategory.ANIMALS to listOf(
            EmojiEntry("🐶", "dog puppy"),
            EmojiEntry("🐱", "cat kitty"),
            EmojiEntry("🐭", "mouse"),
            EmojiEntry("🦊", "fox"),
            EmojiEntry("🐻", "bear"),
            EmojiEntry("🐼", "panda"),
            EmojiEntry("🦁", "lion"),
            EmojiEntry("🐯", "tiger"),
            EmojiEntry("🐸", "frog"),
            EmojiEntry("🦋", "butterfly"),
            EmojiEntry("🐝", "bee"),
            EmojiEntry("🐢", "turtle"),
            EmojiEntry("🦉", "owl"),
            EmojiEntry("🌸", "cherry blossom flower"),
            EmojiEntry("🌿", "herb leaf"),
            EmojiEntry("🌳", "tree")
        ),
        EmojiCategory.FOOD to listOf(
            EmojiEntry("🍕", "pizza"),
            EmojiEntry("🍔", "burger"),
            EmojiEntry("🍟", "fries"),
            EmojiEntry("🌮", "taco"),
            EmojiEntry("🍜", "ramen noodles"),
            EmojiEntry("🍣", "sushi"),
            EmojiEntry("🍩", "donut"),
            EmojiEntry("🍪", "cookie"),
            EmojiEntry("🎂", "cake birthday"),
            EmojiEntry("☕", "coffee"),
            EmojiEntry("🍵", "tea"),
            EmojiEntry("🍎", "apple"),
            EmojiEntry("🍓", "strawberry"),
            EmojiEntry("🥭", "mango")
        ),
        EmojiCategory.TRAVEL to listOf(
            EmojiEntry("✈️", "airplane flight"),
            EmojiEntry("🚀", "rocket launch"),
            EmojiEntry("🚗", "car"),
            EmojiEntry("🚆", "train"),
            EmojiEntry("🚲", "bicycle"),
            EmojiEntry("🏔️", "mountain"),
            EmojiEntry("🏖️", "beach"),
            EmojiEntry("🌆", "cityscape"),
            EmojiEntry("🌍", "earth globe"),
            EmojiEntry("🌙", "moon"),
            EmojiEntry("☀️", "sun"),
            EmojiEntry("🌧️", "rain")
        ),
        EmojiCategory.OBJECTS to listOf(
            EmojiEntry("💡", "lightbulb idea"),
            EmojiEntry("📱", "phone mobile"),
            EmojiEntry("💻", "laptop computer"),
            EmojiEntry("⌨️", "keyboard"),
            EmojiEntry("🎧", "headphones music"),
            EmojiEntry("📷", "camera photo"),
            EmojiEntry("📚", "books"),
            EmojiEntry("📝", "memo note"),
            EmojiEntry("🔒", "lock security"),
            EmojiEntry("🔑", "key"),
            EmojiEntry("⏰", "alarm clock"),
            EmojiEntry("📅", "calendar")
        ),
        EmojiCategory.SYMBOLS to listOf(
            EmojiEntry("✨", "sparkles"),
            EmojiEntry("⭐", "star"),
            EmojiEntry("🔥", "fire lit"),
            EmojiEntry("⚡", "lightning bolt"),
            EmojiEntry("✅", "check done"),
            EmojiEntry("❌", "cross cancel"),
            EmojiEntry("⚠️", "warning"),
            EmojiEntry("ℹ️", "info"),
            EmojiEntry("♻️", "recycle"),
            EmojiEntry("🏳️‍🌈", "rainbow flag"),
            EmojiEntry("🎯", "target bullseye"),
            EmojiEntry("🏆", "trophy win")
        )
    )

    fun search(query: String): List<EmojiEntry> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return catalog.values.flatten().filter {
            it.keywords.contains(q) || it.emoji.contains(q)
        }.distinctBy { it.emoji }
    }
}

class EmojiHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recordUsage(emoji: String) {
        val recent = getRecent().toMutableList()
        recent.remove(emoji)
        recent.add(0, emoji)
        if (recent.size > 30) {
            recent.subList(30, recent.size).clear()
        }
        val arr = JSONArray(recent)

        val freq = getFrequencies().toMutableMap()
        freq[emoji] = (freq[emoji] ?: 0) + 1
        val freqObj = JSONObject()
        freq.forEach { (k, v) -> freqObj.put(k, v) }

        prefs.edit()
            .putString(KEY_RECENT, arr.toString())
            .putString(KEY_FREQ, freqObj.toString())
            .apply()
    }

    fun getRecent(): List<String> {
        val raw = prefs.getString(KEY_RECENT, "[]") ?: "[]"
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun getFrequent(limit: Int = 12): List<String> {
        return getFrequencies().entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { it.key }
    }

    private fun getFrequencies(): Map<String, Int> {
        val raw = prefs.getString(KEY_FREQ, "{}") ?: "{}"
        val map = mutableMapOf<String, Int>()
        try {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optInt(k, 0)
            }
        } catch (_: Exception) {
        }
        return map
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val PREFS = "celeis_emoji_history"
        private const val KEY_RECENT = "recent_emojis"
        private const val KEY_FREQ = "freq_emojis"
    }
}
