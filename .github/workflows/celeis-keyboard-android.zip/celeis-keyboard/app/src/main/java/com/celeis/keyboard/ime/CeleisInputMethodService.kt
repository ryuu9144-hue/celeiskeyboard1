package com.celeis.keyboard.ime

import android.content.Intent
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import com.celeis.keyboard.automation.AutoCounterController
import com.celeis.keyboard.automation.AutoPasteController
import com.celeis.keyboard.automation.StoredPhrasesRepository
import com.celeis.keyboard.clipboard.ClipboardManagerStore
import com.celeis.keyboard.dictionary.DictionaryEngine
import com.celeis.keyboard.emoji.EmojiHistoryStore
import com.celeis.keyboard.input.CursorDirection
import com.celeis.keyboard.input.TextEditingEngine
import com.celeis.keyboard.prefs.CeleisPreferences
import com.celeis.keyboard.privacy.SensitiveFieldDetector
import com.celeis.keyboard.render.KeyboardContainerView
import com.celeis.keyboard.settings.SettingsActivity
import com.celeis.keyboard.themes.ThemeManager
import com.celeis.keyboard.ui.ActivePanel
import com.celeis.keyboard.unicode.TypingMode
import com.celeis.keyboard.voice.VoiceInputController

/**
 * Genuine Android InputMethodService for Celeis Keyboard.
 * Integrates Unicode mode (U+2060), Smart Backspace, Persistent Caps Lock,
 * manual suggestions, clipboard, stored phrases, Auto Counter, AutoPaste,
 * voice typing, themes, and sensitive-field privacy protections.
 */
class CeleisInputMethodService : InputMethodService() {

    private lateinit var prefs: CeleisPreferences
    private lateinit var themeManager: ThemeManager
    private lateinit var textEngine: TextEditingEngine
    private lateinit var dictionary: DictionaryEngine
    private lateinit var clipboardStore: ClipboardManagerStore
    private lateinit var emojiHistoryStore: EmojiHistoryStore
    private lateinit var phrasesRepo: StoredPhrasesRepository
    private lateinit var counterController: AutoCounterController
    private lateinit var autoPasteController: AutoPasteController
    private lateinit var voiceController: VoiceInputController

    private var containerView: KeyboardContainerView? = null
    private var isSensitiveField: Boolean = false

    override fun onCreate() {
        super.onCreate()
        prefs = CeleisPreferences(this)
        themeManager = ThemeManager(this, prefs)
        textEngine = TextEditingEngine(prefs)
        dictionary = DictionaryEngine(this)
        clipboardStore = ClipboardManagerStore(this, prefs)
        emojiHistoryStore = EmojiHistoryStore(this)
        phrasesRepo = StoredPhrasesRepository(this)

        counterController = AutoCounterController(
            onInsertValue = { value ->
                if (!isSensitiveField) {
                    textEngine.commitPhrase(currentInputConnection, value)
                }
            },
            onStateChanged = { state, nextVal ->
                containerView?.updateCounterStatus(state, nextVal)
            }
        )

        autoPasteController = AutoPasteController(
            context = this,
            onInsertPhrase = { phrase ->
                if (!isSensitiveField) {
                    textEngine.commitPhrase(currentInputConnection, phrase)
                }
            },
            onStateChanged = { state ->
                containerView?.updateAutoPasteStatus(state)
            }
        )

        voiceController = VoiceInputController(
            context = this,
            onListeningStateChanged = { _, message ->
                containerView?.setStatusMessage(message)
            },
            onRecognizedText = { recognized ->
                textEngine.commitPhrase(currentInputConnection, recognized)
                refreshSuggestions()
            }
        )

        clipboardStore.startListening()
    }

    override fun onCreateInputView(): View {
        val view = KeyboardContainerView(
            context = this,
            prefs = prefs,
            clipboardStore = clipboardStore,
            emojiHistoryStore = emojiHistoryStore,
            phrasesRepo = phrasesRepo,
            counterController = counterController,
            autoPasteController = autoPasteController,
            callbacks = object : KeyboardContainerView.Callbacks {
                override fun onCharacter(text: String) {
                    textEngine.commitText(currentInputConnection, text, currentInputEditorInfo)
                    containerView?.keyboardView?.setShiftState(textEngine.shiftState)
                    refreshSuggestions()
                }

                override fun onShift() {
                    val state = textEngine.onShiftTap()
                    containerView?.keyboardView?.setShiftState(state)
                }

                override fun onBackspace() {
                    textEngine.performSmartBackspace(currentInputConnection, currentInputEditorInfo)
                    containerView?.keyboardView?.setShiftState(textEngine.shiftState)
                    refreshSuggestions()
                }

                override fun onEnter() {
                    val ic = currentInputConnection ?: return
                    val editorInfo = currentInputEditorInfo
                    val actionId = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
                    val hasCustomAction = actionId != EditorInfo.IME_ACTION_NONE &&
                        actionId != EditorInfo.IME_ACTION_UNSPECIFIED &&
                        (editorInfo?.imeOptions?.and(EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0)

                    if (hasCustomAction) {
                        ic.performEditorAction(actionId)
                    } else {
                        textEngine.commitText(ic, "\n", editorInfo)
                    }
                    containerView?.keyboardView?.setShiftState(textEngine.shiftState)
                    refreshSuggestions()
                }

                override fun onSuggestionSelected(word: String) {
                    textEngine.commitSuggestion(currentInputConnection, word)
                    refreshSuggestions()
                }

                override fun onInsertPhrase(text: String) {
                    textEngine.commitPhrase(currentInputConnection, text)
                    refreshSuggestions()
                }

                override fun onMoveCursor(direction: CursorDirection) {
                    textEngine.moveCursor(currentInputConnection, direction)
                }

                override fun onToggleUnicodeMode() {
                    val next = if (prefs.typingMode == TypingMode.NORMAL) TypingMode.UNICODE else TypingMode.NORMAL
                    prefs.typingMode = next
                    containerView?.refreshConfiguration(themeManager.getActiveTheme(), textEngine.shiftState)
                }

                override fun onVoiceRequested() {
                    voiceController.toggleListening(prefs.activeLanguageCode)
                }

                override fun onOpenSettings(section: String?) {
                    val intent = Intent(this@CeleisInputMethodService, SettingsActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (section != null) putExtra(SettingsActivity.EXTRA_SECTION, section)
                    }
                    startActivity(intent)
                }
            }
        )
        containerView = view
        view.refreshConfiguration(themeManager.getActiveTheme(), textEngine.shiftState)
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        isSensitiveField = SensitiveFieldDetector.isSensitiveField(info)
        clipboardStore.isSensitiveContext = isSensitiveField

        if (isSensitiveField) {
            counterController.stop()
            autoPasteController.stop()
        }

        textEngine.syncFromPreferences()
        textEngine.updateAutoCapitalization(currentInputConnection, info)
        containerView?.refreshConfiguration(themeManager.getActiveTheme(), textEngine.shiftState)
        containerView?.showPanel(ActivePanel.KEYBOARD)
        refreshSuggestions()
    }

    override fun onUpdateSelection(
        oldSelStart: Int,
        oldSelEnd: Int,
        newSelStart: Int,
        newSelEnd: Int,
        candidatesStart: Int,
        candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        textEngine.updateAutoCapitalization(currentInputConnection, currentInputEditorInfo)
        containerView?.keyboardView?.setShiftState(textEngine.shiftState)
        refreshSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        // Stop automation and voice immediately when focus is lost or keyboard closes
        counterController.stop()
        autoPasteController.stop()
        if (voiceController.isListening) {
            voiceController.stopListening()
        }
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return isLandscape && prefs.landscapeFullscreen
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        containerView?.refreshConfiguration(themeManager.getActiveTheme(), textEngine.shiftState)
    }

    override fun onDestroy() {
        super.onDestroy()
        counterController.stop()
        autoPasteController.stop()
        voiceController.stopListening()
        clipboardStore.stopListening()
    }

    private fun refreshSuggestions() {
        val container = containerView ?: return
        if (isSensitiveField || !prefs.showSuggestions) {
            container.updateSuggestions(emptyList())
            return
        }
        val (prefix, prevWord) = textEngine.getCurrentWordPrefix(currentInputConnection)
        val suggestions = dictionary.getSuggestions(
            currentPrefix = prefix,
            previousWord = prevWord,
            includeNextWord = prefs.nextWordSuggestions
        )
        container.updateSuggestions(suggestions)
    }
}
