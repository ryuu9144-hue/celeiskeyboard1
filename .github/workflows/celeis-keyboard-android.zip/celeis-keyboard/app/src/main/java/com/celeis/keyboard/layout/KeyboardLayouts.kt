package com.celeis.keyboard.layout

/**
 * Defines QWERTY and multi-page Symbols layouts, including optional 0-9 number row,
 * accented long-press alternates, mathematical/currency/programming symbols, and Unicode characters.
 */
object KeyboardLayouts {

    private val numberRow: List<KeySpec> = listOf(
        KeySpec("1", "1", altChars = listOf("¹", "½", "⅓", "¼", "⅛")),
        KeySpec("2", "2", altChars = listOf("²", "⅔")),
        KeySpec("3", "3", altChars = listOf("³", "¾", "⅜")),
        KeySpec("4", "4", altChars = listOf("⁴")),
        KeySpec("5", "5", altChars = listOf("⁵", "⅝")),
        KeySpec("6", "6", altChars = listOf("⁶")),
        KeySpec("7", "7", altChars = listOf("⁷", "⅞")),
        KeySpec("8", "8", altChars = listOf("⁸", "∞")),
        KeySpec("9", "9", altChars = listOf("⁹")),
        KeySpec("0", "0", altChars = listOf("⁰", "∅", "°"))
    )

    private val qwertyRow1 = listOf(
        KeySpec("q", "q", altChars = listOf("1", "q̂")),
        KeySpec("w", "w", altChars = listOf("2", "ŵ")),
        KeySpec("e", "e", altChars = listOf("3", "è", "é", "ê", "ë", "ē", "ė", "ę")),
        KeySpec("r", "r", altChars = listOf("4", "ŕ", "ř")),
        KeySpec("t", "t", altChars = listOf("5", "þ", "ť", "ț")),
        KeySpec("y", "y", altChars = listOf("6", "ý", "ÿ")),
        KeySpec("u", "u", altChars = listOf("7", "û", "ü", "ù", "ú", "ū")),
        KeySpec("i", "i", altChars = listOf("8", "î", "ï", "í", "ī", "į", "ì")),
        KeySpec("o", "o", altChars = listOf("9", "ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ")),
        KeySpec("p", "p", altChars = listOf("0", "π"))
    )

    private val qwertyRow2 = listOf(
        KeySpec("", "", KeyType.SPACER, weight = 0.5f),
        KeySpec("a", "a", altChars = listOf("@", "à", "á", "â", "ä", "æ", "ã", "å", "ā")),
        KeySpec("s", "s", altChars = listOf("#", "ß", "ś", "š", "ş")),
        KeySpec("d", "d", altChars = listOf("$", "ð", "ď")),
        KeySpec("f", "f", altChars = listOf("_", "ƒ")),
        KeySpec("g", "g", altChars = listOf("&", "ğ", "ĝ")),
        KeySpec("h", "h", altChars = listOf("-", "ĥ")),
        KeySpec("j", "j", altChars = listOf("+", "ĵ")),
        KeySpec("k", "k", altChars = listOf("(", "ķ")),
        KeySpec("l", "l", altChars = listOf(")", "ł", "ĺ", "ľ")),
        KeySpec("", "", KeyType.SPACER, weight = 0.5f)
    )

    private val qwertyRow3 = listOf(
        KeySpec("⇧", "", KeyType.SHIFT, weight = 1.5f),
        KeySpec("z", "z", altChars = listOf("*", "ž", "ź", "ż")),
        KeySpec("x", "x", altChars = listOf("\"", "×")),
        KeySpec("c", "c", altChars = listOf("'", "ç", "ć", "č")),
        KeySpec("v", "v", altChars = listOf(":")),
        KeySpec("b", "b", altChars = listOf(";")),
        KeySpec("n", "n", altChars = listOf("!", "ñ", "ń", "ň")),
        KeySpec("m", "m", altChars = listOf("?", "µ")),
        KeySpec("⌫", "", KeyType.BACKSPACE, weight = 1.5f)
    )

    private fun buildBottomRow(
        page: KeyboardPage,
        showEmojiKey: Boolean,
        showVoiceKey: Boolean
    ): List<KeySpec> {
        val list = mutableListOf<KeySpec>()
        val symLabel = if (page == KeyboardPage.QWERTY) "?123" else "ABC"
        list.add(KeySpec(symLabel, "", KeyType.SYMBOLS, weight = 1.4f))
        if (showEmojiKey) {
            list.add(KeySpec("☺", "", KeyType.EMOJI, weight = 1.0f))
        }
        list.add(KeySpec(",", ",", KeyType.COMMA, weight = 0.9f, altChars = listOf(";", ":", "!")))
        list.add(KeySpec("English", " ", KeyType.SPACE, weight = 4.2f))
        list.add(KeySpec(".", ".", KeyType.PERIOD, weight = 0.9f, altChars = listOf("?", "!", ",", "'", "\"", "-", "/")))
        if (showVoiceKey) {
            list.add(KeySpec("🎙", "", KeyType.VOICE, weight = 1.0f))
        }
        list.add(KeySpec("↵", "\n", KeyType.ENTER, weight = 1.5f))
        return list
    }

    private val symbolsPage1Row1 = listOf(
        KeySpec("@"), KeySpec("#"), KeySpec("$"), KeySpec("_"), KeySpec("&"),
        KeySpec("-"), KeySpec("+"), KeySpec("("), KeySpec(")"), KeySpec("/")
    )
    private val symbolsPage1Row2 = listOf(
        KeySpec("*"), KeySpec("\""), KeySpec("'"), KeySpec(":"), KeySpec(";"),
        KeySpec("!"), KeySpec("?"), KeySpec("%"), KeySpec("="), KeySpec("\\")
    )
    private val symbolsPage1Row3 = listOf(
        KeySpec("=\\<", "", KeyType.SHIFT, weight = 1.5f),
        KeySpec("~"), KeySpec("`"), KeySpec("|"), KeySpec("^"),
        KeySpec("{"), KeySpec("}"), KeySpec("["), KeySpec("]"),
        KeySpec("⌫", "", KeyType.BACKSPACE, weight = 1.5f)
    )

    // Page 2: Math, Currency, Programming & Unicode
    private val symbolsPage2Row1 = listOf(
        KeySpec("€"), KeySpec("£"), KeySpec("¥"), KeySpec("₹"), KeySpec("₿"),
        KeySpec("¢"), KeySpec("±"), KeySpec("×"), KeySpec("÷"), KeySpec("≠")
    )
    private val symbolsPage2Row2 = listOf(
        KeySpec("≤"), KeySpec("≥"), KeySpec("≈"), KeySpec("∞"), KeySpec("√"),
        KeySpec("∑"), KeySpec("π"), KeySpec("°"), KeySpec("§"), KeySpec("¶")
    )
    private val symbolsPage2Row3 = listOf(
        KeySpec("?123", "", KeyType.SHIFT, weight = 1.5f),
        KeySpec("<"), KeySpec(">"), KeySpec("«"), KeySpec("»"),
        KeySpec("©"), KeySpec("®"), KeySpec("™"), KeySpec("•"),
        KeySpec("⌫", "", KeyType.BACKSPACE, weight = 1.5f)
    )

    fun getRows(
        page: KeyboardPage,
        showNumberRow: Boolean,
        showNumberRowInSymbols: Boolean,
        showEmojiKey: Boolean,
        showVoiceKey: Boolean,
        showAltChars: Boolean
    ): List<List<KeySpec>> {
        val rows = mutableListOf<List<KeySpec>>()
        when (page) {
            KeyboardPage.QWERTY -> {
                if (showNumberRow) rows.add(numberRow)
                rows.add(maybeStripAlts(qwertyRow1, showAltChars))
                rows.add(maybeStripAlts(qwertyRow2, showAltChars))
                rows.add(maybeStripAlts(qwertyRow3, showAltChars))
            }
            KeyboardPage.SYMBOLS_1 -> {
                if (showNumberRowInSymbols) rows.add(numberRow)
                rows.add(symbolsPage1Row1)
                rows.add(symbolsPage1Row2)
                rows.add(symbolsPage1Row3)
            }
            KeyboardPage.SYMBOLS_2 -> {
                if (showNumberRowInSymbols) rows.add(numberRow)
                rows.add(symbolsPage2Row1)
                rows.add(symbolsPage2Row2)
                rows.add(symbolsPage2Row3)
            }
        }
        rows.add(buildBottomRow(page, showEmojiKey, showVoiceKey))
        return rows
    }

    private fun maybeStripAlts(row: List<KeySpec>, showAltChars: Boolean): List<KeySpec> {
        if (showAltChars) return row
        return row.map { it.copy(altChars = emptyList(), hint = null) }
    }
}
