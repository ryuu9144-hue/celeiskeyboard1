package com.celeis.keyboard.unicode

import java.text.BreakIterator
import java.util.Locale

/**
 * Typing mode for Celeis Keyboard.
 */
enum class TypingMode {
    NORMAL,
    UNICODE
}

/**
 * Core Unicode processor for Celeis Keyboard.
 *
 * Signature feature:
 * In [TypingMode.UNICODE], every English alphabet letter ([A-Za-z]) typed
 * is immediately followed by U+2060 WORD JOINER (\u2060).
 * Numbers, punctuation, spaces, and non-English characters are never suffixed.
 *
 * Smart Backspace:
 * When the cursor is immediately after `[A-Za-z]\u2060`, both the letter and
 * its associated U+2060 are deleted as a single logical unit. Otherwise, one
 * complete grapheme cluster (handling surrogate pairs and emoji ZWJ sequences)
 * is deleted.
 */
object UnicodeProcessor {

    const val WORD_JOINER: Char = '\u2060'
    const val WORD_JOINER_STR: String = "\u2060"

    fun isEnglishLetter(ch: Char): Boolean {
        return ch in 'a'..'z' || ch in 'A'..'Z'
    }

    /**
     * Formats a single committed character or string according to the active [mode].
     *
     * @param input The raw text to commit (e.g., "a", "B", "1", ".", " ").
     * @param mode Current [TypingMode].
     * @param textAfterCursor Optional text immediately after the cursor to guard against
     * duplicate U+2060 insertion when editing mid-word.
     */
    fun processInput(
        input: String,
        mode: TypingMode,
        textAfterCursor: CharSequence? = null
    ): String {
        if (input.isEmpty() || mode == TypingMode.NORMAL) {
            return input
        }

        // Single-character fast path (most common during typing)
        if (input.length == 1) {
            val ch = input[0]
            if (isEnglishLetter(ch)) {
                val alreadyHasJoinerAfter =
                    !textAfterCursor.isNullOrEmpty() && textAfterCursor[0] == WORD_JOINER
                return if (alreadyHasJoinerAfter) {
                    input
                } else {
                    "$ch$WORD_JOINER"
                }
            }
            return input
        }

        // Multi-character input (e.g. suggestion tap or phrase):
        // Avoid duplicating U+2060 if the input already contains joiners.
        val sb = StringBuilder(input.length * 2)
        for (i in input.indices) {
            val ch = input[i]
            sb.append(ch)
            if (isEnglishLetter(ch)) {
                val nextInInputIsJoiner = (i + 1 < input.length) && input[i + 1] == WORD_JOINER
                val isLastAndFollowedByJoiner =
                    (i == input.lastIndex) &&
                        !textAfterCursor.isNullOrEmpty() &&
                        textAfterCursor[0] == WORD_JOINER
                if (!nextInInputIsJoiner && !isLastAndFollowedByJoiner) {
                    sb.append(WORD_JOINER)
                }
            }
        }
        return sb.toString()
    }

    /**
     * Computes how many UTF-16 code units before the cursor should be deleted
     * for Smart Backspace.
     *
     * @param textBeforeCursor Text immediately preceding the cursor.
     * @return Number of UTF-16 code units to delete (0 if nothing before cursor).
     */
    fun computeSmartBackspaceLength(textBeforeCursor: CharSequence?): Int {
        if (textBeforeCursor.isNullOrEmpty()) return 0
        val str = textBeforeCursor.toString()
        val len = str.length

        // Case 1: Cursor is immediately after [A-Za-z] + U+2060
        if (len >= 2 && str[len - 1] == WORD_JOINER && isEnglishLetter(str[len - 2])) {
            return 2
        }

        // Case 2: Orphan U+2060 not preceded by an English letter -> delete just the joiner
        if (str[len - 1] == WORD_JOINER) {
            return 1
        }

        // Case 3: General Unicode grapheme cluster (surrogate pairs, combining marks, ZWJ emojis)
        val iterator = BreakIterator.getCharacterInstance(Locale.ROOT)
        iterator.setText(str)
        val end = iterator.last()
        val prev = iterator.previous()
        return if (prev != BreakIterator.DONE && end > prev) {
            end - prev
        } else {
            // Fallback for surrogate pairs
            if (len >= 2 && Character.isLowSurrogate(str[len - 1]) && Character.isHighSurrogate(str[len - 2])) {
                2
            } else {
                1
            }
        }
    }

    /**
     * Strips all U+2060 WORD JOINER characters for dictionary lookup / prefix matching
     * so suggestions work seamlessly in Unicode mode.
     */
    fun stripWordJoiners(text: CharSequence?): String {
        if (text.isNullOrEmpty()) return ""
        val sb = StringBuilder(text.length)
        for (i in text.indices) {
            val ch = text[i]
            if (ch != WORD_JOINER) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }
}
