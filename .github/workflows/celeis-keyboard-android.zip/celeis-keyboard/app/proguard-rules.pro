# ProGuard rules for Celeis Keyboard
-keep class com.celeis.keyboard.ime.CeleisInputMethodService { *; }
-keep class com.celeis.keyboard.settings.** { *; }
