# Celeis Keyboard

A native Kotlin Android Input Method Editor (IME) featuring everyday QWERTY productivity, deep visual customization, privacy-first local storage, and Celeis's signature **Unicode Mode (`U+2060 WORD JOINER`)** with **Smart Backspace**.

## Key Features

- **Native Android IME (`InputMethodService`)**: Targets Android 8.0+ (`minSdk = 26`, `compileSdk = 35`, `targetSdk = 35`).
- **Two Typing Modes**:
  - **Normal Mode**: Standard QWERTY typing.
  - **Unicode Mode**: Automatically appends `U+2060` (`\u2060` WORD JOINER) after every English alphabet letter (`[A-Za-z]`). Numbers, punctuation, spaces, and non-English characters are not suffixed. Guards against duplicate joiners.
  - **Smart Backspace**: Deletes `[A-Za-z]\u2060` as a single logical unit, and handles general Unicode grapheme clusters, surrogate pairs, and multi-code-point ZWJ emojis via `BreakIterator`.
- **Keyboard Engine & Layouts**:
  - QWERTY, optional 0–9 number row, multi-page Symbols (math, currency, programming, Unicode), long-press accented & symbol popups.
  - Single-tap Shift, double-tap Persistent Caps Lock (survives keyboard close & app switch), and sentence capitalization.
  - Configurable Keypress Delay (`10–1000 ms`), Key Hold Delay (`150–1000 ms`), Popup Visibility, Sounds, and Haptic Intensity.
- **Resizing & Adaptation**:
  - Independent Portrait & Landscape height sliders, overall Width %, Bottom Offset, Key Spacing (H/V), Corner Radius, Border Width, Font Size, and One-Handed Mode (Left/Right + adjustable width).
  - Handles system bars, gesture navigation, three-button navigation, and display cutouts via `WindowInsetsCompat`.
- **Themes & Gallery Backgrounds**:
  - Built-in themes (**Celeis Default Dark** as default, Light, Dark, Day Mode, Night Mode AMOLED, Midnight Violet, Emerald Slate).
  - Custom themes using Android's System Photo Picker (`PickVisualMedia`, no storage permissions required) with adjustable background opacity.
- **Toolbar, Functions Panel & Text Tools**:
  - **Arrow Navigation** (`←`, `↑`, `↓`, `→`) via `DPAD` key events.
  - **Clipboard Manager**: Local history, pin/unpin, delete, clear, sensitive-field pause, Android 13+ `EXTRA_IS_SENSITIVE` respect.
  - **Stored Phrases**: Add, edit, delete, reorder, and cycle through saved phrases.
  - **Auto Counter**: Numeric (`1, 2, 3...`) and Alphabetic (`A..Z, AA, AB...`) modes with Start, Pause, Resume, Stop, Reset, custom start, and custom interval.
  - **AutoPaste**: Cycles 1–3 phrases into the focused field only (never presses Send; stops on focus loss or sensitive fields).
  - **Dictionary & Suggestions**: Manual-tap word & next-word suggestions + Personal Dictionary. **No autocorrect, no automatic replacement, no swipe typing.**
  - **Voice Typing**: Uses Android `SpeechRecognizer` with runtime `RECORD_AUDIO` permission and service availability checks.

## Language Support

| Language | Status | Notes |
| --- | --- | --- |
| English (US / UK) | **Fully Supported** | QWERTY layout, dictionary, next-word suggestions, Unicode `U+2060` mode |
| Additional Languages | **Architecture Ready** | Subtype & layout hooks in `method.xml` and `KeyboardLayouts`; dictionaries not yet bundled |

## Privacy & Security

- **Zero `INTERNET` permission** in `AndroidManifest.xml`.
- Typed text, clipboard history, stored phrases, personal dictionary words, and custom themes are stored **exclusively on-device** in app-private storage.
- In password, PIN, and `IME_FLAG_NO_PERSONALIZED_LEARNING` fields, Celeis automatically disables suggestions, pauses clipboard capture, and blocks/stops Auto Counter and AutoPaste.

## Building the APK

### Option 1: GitHub Actions (Recommended if building in the cloud)
1. Push this project to a GitHub repository.
2. Open the **Actions** tab and run **Android CI - Celeis Keyboard** (`.github/workflows/android-ci.yml`).
3. Download the `celeis-keyboard-debug-apk` artifact from the completed workflow run.

### Option 2: Android Studio / Local CLI
1. Open the `celeis-keyboard` folder in **Android Studio** (JDK 17, Android SDK 35).
2. Let Gradle sync, then run **Build > Build Bundle(s) / APK(s) > Build APK(s)** or:
   ```bash
   gradle testDebugUnitTest assembleDebug
   ```
3. Install the generated APK from `app/build/outputs/apk/debug/`.

## Installation & Enabling

1. Install the APK on your Android 8.0+ device.
2. Open **Celeis Keyboard** from your app drawer.
3. Tap **1. Enable Celeis Keyboard in Android Settings** and toggle Celeis Keyboard ON.
4. Tap **2. Switch Active Keyboard to Celeis** and select **Celeis Keyboard**.
5. Use the **Try out your setup** bar at the bottom of Settings to test your layout immediately.

## Release Checklist (Honest Verification Status)

*Note: Because the build sandbox lacks the Android SDK and Gradle, compilation and emulator/device execution have not been run in this environment.*

- [ ] Native Android keyboard works — **IMPLEMENTED / UNTESTED**
- [ ] Normal mode works — **IMPLEMENTED / UNTESTED**
- [ ] Unicode mode works — **IMPLEMENTED / UNTESTED**
- [ ] U+2060 insertion works — **IMPLEMENTED / UNTESTED**
- [ ] Smart Backspace works — **IMPLEMENTED / UNTESTED**
- [ ] Persistent Caps Lock works — **IMPLEMENTED / UNTESTED**
- [ ] Number row works — **IMPLEMENTED / UNTESTED**
- [ ] Symbols work — **IMPLEMENTED / UNTESTED**
- [ ] Emoji works — **IMPLEMENTED / UNTESTED**
- [ ] Clipboard works — **IMPLEMENTED / UNTESTED**
- [ ] Stored Phrases work — **IMPLEMENTED / UNTESTED**
- [ ] Auto Counter works — **IMPLEMENTED / UNTESTED**
- [ ] AutoPaste works — **IMPLEMENTED / UNTESTED**
- [ ] Themes work — **IMPLEMENTED / UNTESTED**
- [ ] Gallery backgrounds work — **IMPLEMENTED / UNTESTED**
- [ ] Keyboard resizing works — **IMPLEMENTED / UNTESTED**
- [ ] Height adjustment works — **IMPLEMENTED / UNTESTED**
- [ ] Width adjustment works — **IMPLEMENTED / UNTESTED**
- [ ] Key spacing works — **IMPLEMENTED / UNTESTED**
- [ ] One-handed mode works — **IMPLEMENTED / UNTESTED**
- [ ] Landscape layout works — **IMPLEMENTED / UNTESTED**
- [ ] Dictionary works — **IMPLEMENTED / UNTESTED**
- [ ] Suggestions work without autocorrect — **IMPLEMENTED / UNTESTED**
- [ ] Voice typing works where supported — **IMPLEMENTED / UNTESTED**
- [ ] Settings persist — **IMPLEMENTED / UNTESTED**
- [ ] Sensitive-field protections work — **IMPLEMENTED / UNTESTED**
- [ ] Tests pass — **IMPLEMENTED / UNTESTED** (unit & Robolectric tests written; run via CI or Android Studio)
- [ ] APK builds successfully — **NOT BUILT IN SANDBOX** (no Android SDK/Gradle in VM; GitHub Actions workflow included)
